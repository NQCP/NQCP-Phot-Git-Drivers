from distutils.core import setup, Extension

LDA_module = Extension('LDA_module',
                       sources = ['LDA_module.c'],
                       extra_objects = ['src/LDAhid.o'],
                       libraries = ['usb-1.0'],
                       include_dirs=['/usr/include/libusb-1.0', 'include'])


setup(name = 'Vaunix LDA Python 3 support',
      version = '0.1',
      description = 'Python Package for Vaunix LDA RF Attenuators',
      ext_modules = [LDA_module],

      url='http://www.vaunix.com',
      author='JA for Vaunix, Inc.',
      author_email='LabBrickSupport@vaunix.com')
