import sys
from ctypes import *

# Load the LDA Linux shared library
vnx = cdll.LoadLibrary('libLDAhid.so')

# API constant: Array size for device list
MAX_LDA_DEVICES = 64

# Set API to use actual hardware
vnx.fnLDA_SetTestMode(False)

# Prepare device ID array
DeviceIDArray = c_int * MAX_LDA_DEVICES
Devices = DeviceIDArray()

# Initialize the library
vnx.fnLDA_Init()

# Detect devices
num_devices = vnx.fnLDA_GetNumDevices()
print(f'{num_devices} device(s) found')

if num_devices == 0:
    print("No Vaunix LDA devices located. Exiting.")
    sys.exit(1)

# Populate device ID array
dev_info = vnx.fnLDA_GetDevInfo(Devices)
print('GetDevInfo returned', dev_info)

# Example: Print model/serial, initialize, query/set frequency and attenuation, then close each device
for idx in range(dev_info):
    dev_id = Devices[idx]
    print(f'\n---------- Device {dev_id} ---------------------------')


    # Get model name
    ModelNameArray = create_string_buffer(64)
    model_len = vnx.fnLDA_GetModelName(dev_id, ModelNameArray)
    print(f'  Model: {ModelNameArray.value.decode()}')

    # Get serial number
    serial = vnx.fnLDA_GetSerialNumber(dev_id)
    print(f'  Serial number: {serial}')

    # Initialize device
    init_status = vnx.fnLDA_InitDevice(dev_id)
    print(f'  InitDevice returned {init_status}')

    # Query frequency range
    min_freq = vnx.fnLDA_GetMinWorkingFrequency(dev_id)
    max_freq = vnx.fnLDA_GetMaxWorkingFrequency(dev_id)
    print(f'  Min frequency (100kHz units): {min_freq},  Max frequency: {max_freq}')

    # Query attenuation range
    min_atten = vnx.fnLDA_GetMinAttenuation(dev_id) / 20
    max_atten = vnx.fnLDA_GetMaxAttenuation(dev_id) / 20
    print(f'  Min Attenuation: {min_atten},  Max Attenuation: {max_atten}')

    num_channels = vnx.fnLDA_GetNumChannels(dev_id)
    for ch in range(num_channels):
        ch += 1
        print(f'-------- Channel {ch}/{num_channels} ----------')

        vnx.fnLDA_SetChannel(dev_id, ch)

        # Read back settings
        set_freq = vnx.fnLDA_GetWorkingFrequency(dev_id)
        set_phase = vnx.fnLDA_GetAttenuation(dev_id)
        print(f'  Current Frequency: {set_freq}, Current Attenuation: {set_phase}')

        # Set frequency (example: set to midpoint of range)
        freq_mid = int((min_freq + max_freq) // 2)
        status = vnx.fnLDA_SetWorkingFrequency(dev_id, freq_mid)
        print(f'  SetWorkingFrequency({freq_mid}) returned {status}')

        # Set attenuation (example: set to 25 dB)
        status = vnx.fnLDA_SetAttenuation(dev_id, 25 * 20)
        print(f'  SetAttenuation(25 * 20) returned {status}')

        # Read back settings
        set_freq = vnx.fnLDA_GetWorkingFrequency(dev_id)
        set_phase = vnx.fnLDA_GetAttenuation(dev_id)
        print(f'  Current Frequency: {set_freq}, Current Attenuation: {set_phase}')

    # Always close when done
    close_status = vnx.fnLDA_CloseDevice(dev_id)
    print(f'CloseDevice returned {close_status}')