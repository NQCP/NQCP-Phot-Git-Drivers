Read me
-------------
Method 1 (with setup script):
-------------------
1: Build the library with make.
> make clean
> make

2: Navigate to the libLDAhid directory.
> cd libLDAhid

3: Execute the below auto install script for additional pacakges to be installed on linux ubuntu system.
> sudo chmod +xr pi_setup.sh
> sudo ./pi_setup.sh

4: Navigate to the Python_Example directory.
> cd ../Python_Example

5: Execute the python test application.
> sudo python3 LDA_test.py


Method 2 (without setup script):
-------------
1: Build the library with make.
> make clean
> make

2: Navigate to the Python_Example directory.
> cd Python_Example

3: Run the test python based app using .so file. Ensure that the .so file is in the /usr/lib/ directory.
> sudo python3 ldalibtest.py
