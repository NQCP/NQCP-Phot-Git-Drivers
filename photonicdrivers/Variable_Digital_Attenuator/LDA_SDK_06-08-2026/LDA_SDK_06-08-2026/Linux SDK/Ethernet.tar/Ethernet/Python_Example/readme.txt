Read me 
-------------
Before using the python command line example program:

The libldasock.so shared library should be copied to your /usr/lib directory. Normally this
copy will require elevated privileges, so your copy command will look like:

> sudo cp <location of the library> /usr/lib

-------------
To run the python command line example program:

# CLI app help output
> python3 ldacli.py -h
ldacli.py -i <ipaddress> -a <attenuation> -f <frequency> -c <channel> -s <rampstart> -e <rampend> -w <dwelltime> -d < idletime> -o <holdtime> -b <bidirectional-dwelltime> -D <rampdirection[0-Up,1-Down]> -M <rampmode[0-Once,1-Continuous,2-Off]> -B <rampbidirectional[0-Unidirectional,1-Bidirectional]> -C <profilecount> -I <profileidletime> -W <profiledwelltime>  -O <profilemode[0-Off,1-Once,2-Repeat]> -S <savesetting> -F <profilefile> -r <read>

-------------
Example commands:

# set the attenuation on two channels of a device
python3 ldacli.py -i 192.168.100.10 -c 1 -a 25 -c 2 -a 30

# read the settings for two channels of a device
python3 ldacli.py -i 192.168.100.10 -c 1 -r -c 2 -r

# Load the profile data in Repeat mode
python3 ldacli.py -i 192.168.100.10 -F ./test_profile.prf -O 2

# Stop the profile Mode
python3 ldacli.py -i 192.168.100.10 -O 0

-------------
The python command line example program is intended to show you how you can use the LDA socket library
from your own application software, and provide a simple example of a command line program you can
customize to perform the functions you want.
