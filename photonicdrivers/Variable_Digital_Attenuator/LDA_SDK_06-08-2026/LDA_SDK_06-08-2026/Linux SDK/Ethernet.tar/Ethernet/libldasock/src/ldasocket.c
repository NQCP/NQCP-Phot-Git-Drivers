// -------------------------------------------------------------------------------------------------------------------------
// Module Name: LDA Ethernet Socket Communication Device Control Linux Library
// JA 01/29/2020    Initial Verison oF Ethernet Library
// RD 05/03/2024    Updates, fixes, new mc functions etc. 
// NJB 5/12/2026    Fixed set idle/profileidle minimum value to be 0
// NJB 5/18/2026    Fix to ensure that threads close properly when the device is closed
//                  Compatibility updates to be more consistent with LDA Windows Ethernet Library
//                  Incremented library version number to 1.1.0
// -------------------------------------------------------------------------------------------------------------------------
// This library uses .05db units for attenuation values, so 10db is represented by 200. (multiply by 20 to convert db to api units)

/// ---------- Include headers ----------------
#include <stdbool.h>
#include <stdint.h>         
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <time.h>
#include <errno.h>
#include <sys/socket.h>
#include <arpa/inet.h> 
#include <netdb.h>
#include <poll.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <fcntl.h>
#include <errno.h>
#include <netinet/in.h>
#include <sys/timerfd.h>
#include <sys/wait.h> 
#include <stdatomic.h>
#include "ldasocket.h"

/// ---------- Macros ----------------
#define LDA_SOCKET_PORT  "40001"
#define FALSE 0
#define TRUE 1          
#define PACKET_CTRL_LEN 8
#define PACKET_INT_LEN  8

#define LIBVER "1.1"
#define LDA_DLLVERSION 0x101        // we return an integer representation of the version with one byte each for major and minor version

// to force LDA library debugging messages choose the following definitions
#define DEBUG_OUT 0     /* set this to 1 in order to see debugging output, 2 for a ton of output, or 3 for many tons */

// IP Address Validator
#define DELIM "."

// Socket connetion timeout
#define CONNECTION_TIMEOUT_SEC 5

// Command Send Throttling Macros
#define TCP_SEND_INTERVAL 200       // This is the default delayed ACK time
#define MAX_COMMANDS_PER_WINDOW 48

// Thread States Macros
#define THREAD_IDLE 0
#define THREAD_START 1
#define THREAD_EXIT 3
#define THREAD_DEAD 4
#define THREAD_ERROR -1

/* -----------------------------------------------------------------
Global Data to maintain the Devices data & states for each process
-------------------------------------------------------------------*/
bool TestMode = FALSE;          // if TestMode is true we fake it -- no HW access
int  ldadevcount = 0;
time_t starttime;
LDAPARAMS lda [MAXDEVICES];      // an array of structures each of which holds the info for a given device

/* stuff for the threads */
pthread_t threads[MAXDEVICES];
int stop_thread[MAXDEVICES];
int thread_running[MAXDEVICES];

/* stuff for device init */
pthread_mutex_t dev_init_locks[MAXDEVICES] = { [0 ... MAXDEVICES-1] = PTHREAD_MUTEX_INITIALIZER };

/* stuff for throttling */
pthread_mutex_t throttle_locks[MAXDEVICES] = { [0 ... MAXDEVICES-1] = PTHREAD_MUTEX_INITIALIZER };
int win_command_counts[MAXDEVICES] = {0};

static struct timespec prev_cmd_times[MAXDEVICES] = {0};


/// ---------- Const Defintions----------
// product names
const char *sVNX_devicenames[] ={"LDA-102" , "LDA-602", "LDA-302P-H", "LDA-302P-1", "LDA-302P-2", "LDA-102-75",
                                  "LDA-102E", "LDA-602E", "LDA-183", "LDA-203", "LDA-102EH", "LDA-602EH", 
                                  "LDA-602Q", "LDA-906V", "LDA-133", "LDA-5018", "LDA-5040", "LDA-906V-8",
                                  "LDA-802EH", "LDA-802Q", "LDA-802-8", "LDA-906V-4"};

char STATUS_QUERY_ID[]= {VNX_GETSERNUM, VNX_MAXCHANNEL, VNX_MODELNAME, VNX_SWVERSION, VNX_IPMODE, VNX_IPADDR, VNX_IPMASK,
                         VNX_IPGW, VNX_MINFREQUENCY, VNX_MAXFREQUENCY,
                         VNX_MINATTEN, VNX_MAXATTEN, VNX_CHANNEL, VNX_FREQUENCY, VNX_PWR, VNX_ASTART, VNX_ASTOP,
                         VNX_ASTEP, VNX_ASTEP2, VNX_ADWELL, VNX_ADWELL2, VNX_AIDLE, VNX_AHOLD,
                         VNX_RFMUTE, VNX_PROFILECOUNT, VNX_PROFILEDWELL, VNX_PROFILEIDLE, VNX_SETPROFILE, VNX_SWEEP};

char LibVersion[] = LIBVER;

static void *rxdatahandler_callback (void *ptr);

/// ----------  Static Function Calls ----------------
//***************************************************************************
//
// Function call for returning the LibVersion
//
//*****************************************************************************
char* fnLDA_LibVersion(void) {
    return LibVersion;
}

//***************************************************************************
//
// Function call for returning the DLL Library Version
//
//*****************************************************************************
int fnLDA_GetLibVersion(void){
    return LDA_DLLVERSION;
}

//***************************************************************************
//
// Function call for Setting test mode
//
//*****************************************************************************
void fnLDA_SetTestMode(bool testmode) {
    TestMode = testmode;
}


//***************************************************************************
//
// Function call for delay loop
//
//*****************************************************************************
/* usleep is deprecated, so this is a function using nanosleep() */
void catnap(long naptime) {
  // naptime comes in as the number of ms we want. 20 = 20ms
  struct timespec sleepytime;
   sleepytime.tv_sec = 0;
   sleepytime.tv_nsec = naptime * 1000000L;

   nanosleep(&sleepytime , NULL);
}

//***************************************************************************
//
// Function call for delay loop
//
//*****************************************************************************
/* usleep is deprecated, so this is a function using nanosleep() */
void sleep_ms(long naptime) {
  // naptime comes in as the number of ms we want. 20 = 20ms
  struct timespec timeval;
   timeval.tv_sec = 0;
   timeval.tv_nsec = naptime * 1000000L;

   nanosleep(&timeval , NULL);
}

//***************************************************************************
//
// Wait for the device's buffer to be empty
//
//*****************************************************************************
// bool wait_for_empty_buffer(int devid) {
//     bool result;
//     const int MAX_RETRIES = 10;
//     int retries = 0;
//     BYTE VNX_param[6] = {0, 0, 0, 0, 0, 0};

//     result = GetDeviceStatus(devid);
//     while (((lps[devid].DevStatus[0] & DEV_BUFEMPTY) == 0 || !result || status_empty) && retries++ < MAX_RETRIES) {
//         sleep_ms(TCP_SEND_INTERVAL);
//         result = GetDeviceStatus(devid);
//     }

//     if (retries >= MAX_RETRIES) {
//         if (DEBUG_OUT > 0) {
//             printf("Warning: Timeout waiting for buffers to empty on device %d\n", devid);
//             return false;
//         }
//     }

//     return true;
// }

//***************************************************************************
//
// Throttle the number of commands sent to the device if we are sending too many
//
//****************************************************************************
bool maybe_throttle(int devid) {
    int cur_ms;
    int prev_ms;
    struct timespec ts;

    // Get the current time
    clock_gettime(CLOCK_MONOTONIC, &ts);
    // Calculate the time in ms of the start of the window versus current time in ms
    prev_ms = (prev_cmd_times[devid].tv_sec * 1000) + (prev_cmd_times[devid].tv_nsec / 1000000);
    cur_ms = (ts.tv_sec * 1000) + (ts.tv_nsec / 1000000);

    if (cur_ms - prev_ms > TCP_SEND_INTERVAL) {
        // Reset the window
        win_command_counts[devid] = 0;
    } else if (win_command_counts[devid] > MAX_COMMANDS_PER_WINDOW && prev_ms != 0) {
        // The maximum command count has been hit for this window
        sleep_ms(TCP_SEND_INTERVAL);
        // Check if the buffer is empty
        // if (!wait_for_empty_buffer(devid)) return false;     // This needs to be added

        win_command_counts[devid] = 0;
    }

    // Keep track of the time for this command send
    clock_gettime(CLOCK_MONOTONIC, &ts);
    prev_cmd_times[devid] = ts;
    
    // Increment the command counter
    win_command_counts[devid]++;
    return true;
}

//***************************************************************************
//
// Validate netconfig digits and return 1 if string contain only digits, else return 0
//
//*****************************************************************************
static int valid_digit(char *ip_str){
    while (*ip_str) {
        if (*ip_str >= '0' && *ip_str <= '9')
            ++ip_str;
        else
            return 0;
    }
    return 1;
}

//***************************************************************************
//
// Validate IP Configuration -return 1 if IP string is valid, else return 0
//
//*****************************************************************************
static int is_valid_ip(char *ip_str){
    int num, dots = 0;
    char *ptr;
    char lstr[16];
    strcpy(lstr,ip_str);

    if (lstr == NULL)
        return 0;

    ptr = strtok(lstr, DELIM);

    if (ptr == NULL)
        return 0;

    while (ptr) {

        /* after parsing string, it must contain only digits */
        if (!valid_digit(ptr))
            return 0;

        num = atoi(ptr);

        /* check for valid IP */
        if (num >= 0 && num <= 255) {
            /* parse remaining string */
            ptr = strtok(NULL, DELIM);
            if (ptr != NULL)
                ++dots;
        } else
            return 0;
    }

    /* valid IP string must contain 3 dots */
    if (dots != 3)
        return 0;
    return 1;
}

//***************************************************************************
//
// Function call to Get DeviceID based on the deviceip from the device entry list
//
//*****************************************************************************
static int GetDeviceID(char* deviceip){
    int i;

    // Loop through to get the device index
	// the array has one extra element since we start active HW devices at lda[1] 
    for(i = 0; i < MAXDEVICES; i++)
    {
        if(strcmp(lda[i].deviceip, deviceip) == 0)
            return i;
    }

    return -1;
}

//***************************************************************************
//
// Function call to check whether lda device socket is open or not
//
//*****************************************************************************
static bool isDeviceSockOpen(char* deviceip) {
  int devid;
  if (TestMode) return TRUE;		// in test mode all devices are always available
  devid = GetDeviceID(deviceip);

  if (DEBUG_OUT > 0) printf("devid:%d\n",devid);

  if(devid >= 0)
  {
      if (DEBUG_OUT > 1) printf(" In isDeviceSockOpen devicesockfd:%d\n",lda[devid].devicesockfd);

      // Even for multichannel devices, we can use channel 0 to know if the device is open
      if (lda[devid].devicesockfd != 0)
        return TRUE;
      else
        return FALSE;
  }
  else
    return FALSE;
}
//***************************************************************************
//
// Function call to Open the Device Socket Connection
//
//*****************************************************************************
static int vnxDeviceOpen(char* deviceip) {
    int sockfd;
    struct addrinfo hints;
    struct addrinfo *result, *rp;
    int flags;
    int iResult;

    memset(&hints, 0, sizeof(struct addrinfo));
    hints.ai_canonname = NULL;
    hints.ai_addr = NULL;
    hints.ai_next = NULL;
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_flags = AI_NUMERICSERV;

    if (DEBUG_OUT > 1) printf("IP:%s\n",deviceip);
 
    // Convert IPv4 and IPv6 addresses from text to binary form 
    if(inet_pton(AF_INET, deviceip, &hints.ai_addr)<=0)  
    { 
        if (DEBUG_OUT > 0) printf("\nInvalid address/ Address not supported \n"); 
        return -1; 
    } 

    // Check if Device is already open or not
    if (getaddrinfo(deviceip, LDA_SOCKET_PORT, &hints, &result) != 0)
        return -1;

    for (rp = result; rp != NULL; rp = rp->ai_next)
    {
        //  Open the Socket Connection 
        sockfd = socket(rp->ai_family, rp->ai_socktype, rp->ai_protocol);
        if (sockfd == -1)
            continue;

        // Set socket to non-blocking
        flags = fcntl(sockfd, F_GETFL, 0);
        if (flags == -1) {
            close(sockfd);
            continue;
        }
        if (fcntl(sockfd, F_SETFL, flags | O_NONBLOCK) == -1) {
            close(sockfd);
            continue;
        }

        iResult = connect(sockfd, rp->ai_addr, rp->ai_addrlen);
        if (iResult < 0) {
            if (errno != EINPROGRESS) {
                close(sockfd);
                sockfd = -1;
                continue;
            }
        }

        if (iResult < 0) {
            fd_set writefds;
            FD_ZERO(&writefds);
            FD_SET(sockfd, &writefds);

            struct timeval tv;
            tv.tv_sec = CONNECTION_TIMEOUT_SEC;
            tv.tv_usec = 0;

            iResult = select(sockfd + 1, NULL, &writefds, NULL, &tv);
            if (iResult <= 0) {
                close(sockfd);
                sockfd = -1;
                continue;
            }

            // Check if the connection actually succeeded
            int optVal;
            socklen_t optLen = sizeof(optVal);
            if (getsockopt(sockfd, SOL_SOCKET, SO_ERROR, &optVal, &optLen) < 0 || optVal != 0) {
                close(sockfd);
                sockfd = -1;
                continue;
            }
        }

        // Restore blocking mode
        if (fcntl(sockfd, F_SETFL, flags & ~O_NONBLOCK) == -1) {
            close(sockfd);
            sockfd = -1;
            continue;
        }

        //Successfully connected
        break;
    }

    if (rp == NULL)
    {
        if (sockfd != -1) close(sockfd);
        return -1;
    }

    freeaddrinfo(result);

    return sockfd;
}

//***************************************************************************
//
// Function call to Send the VNX commands through the Socket to the given ip
//  device. This function waits for the response from get commands
//*****************************************************************************
static bool SendReport(int deviceID, char command, char *pBuffer, int cbBuffer)
{
  int index;
  int timedout;

  // Just in case we were sent here by mistake
  if (TestMode) return TRUE;

  // Check if we are sending too many commands to the device
  // This will wait a little bit if so
  pthread_mutex_lock(&throttle_locks[deviceID]);
  if (!maybe_throttle(deviceID)) {
    // Something went wrong with throttling, don't send!
    pthread_mutex_unlock(&throttle_locks[deviceID]);
    return FALSE;
  }
  pthread_mutex_unlock(&throttle_locks[deviceID]);

  // Make sure the buffer that is being passed to us fits
  if (cbBuffer > HR_BLOCKSIZE) {
    // Report too big, don't send!
    return FALSE;
  }

  // lets make sure our command doesn't have any junk bits in it
  for (index=0; index<HID_REPORT_LENGTH; index++)
      lda[deviceID].sndbuff[index] = 0;

  if (DEBUG_OUT > 1) printf("SR: command=%x cbBuffer=%d\r\n", (uint8_t)command, cbBuffer);
  lda[deviceID].sndbuff[0] = command;       // command to device
  lda[deviceID].sndbuff[1] = cbBuffer;
  for (index=0; index<cbBuffer; index++)
    lda[deviceID].sndbuff[index+2] = pBuffer[index];

  if (DEBUG_OUT > 1) {
    printf("SR to device %d: ", deviceID);
    for (index=0; index<8; index++) {
      printf("%02x ", (uint8_t)lda[deviceID].sndbuff[index]);
    }
    printf("\r\n");
  }

  lda[deviceID].responseready = 0; // Clear Device Response before command send

  // Call Socket Function to send packet data to the device
  if (write(lda[deviceID].devicesockfd, lda[deviceID].sndbuff, PACKET_CTRL_LEN) < 0 )
    {
        if (DEBUG_OUT > 0) printf("sending Message Error!");
    }

  //Check for Get/Set Message type and only wait for response to Get messages
  if((command &  VNX_SET) == 0)
  {
	  // --- then we wait for the read thread's parser to signal that it got the response
	  starttime = time(NULL);
	  timedout = 0;
	  
	  // wait until the value is decoded or 1 second has gone by
	  // RD 4-2019 modified to yield the thread during the wait
	  while ((!lda[deviceID].responseready) && (0 == timedout)) {
	    catnap(10);   // yield for 10 ms, speed matters here
	    if ((time(NULL)-starttime) > 1)
		{
			if (DEBUG_OUT > 0) printf("Timeout waiting for response to %x command", command);
			timedout = 1;
		}
	  }

	  return (0 == timedout) ? TRUE : FALSE;
  }
  else
  	return TRUE;
}


//***************************************************************************
//
// Function call to clear caches in the device data structures with default data
//  
//*****************************************************************************
static void ClearDevCache(DEVID deviceID, int num_channels) {
    int chnl;
    int index;

    if (num_channels > CHANNEL_MAX) num_channels = CHANNEL_MAX; // protect our arrays

    lda[deviceID].MinFrequency = 200;
    lda[deviceID].MaxFrequency = 8000;

    for (chnl = 0; chnl< num_channels; chnl++) {
        lda[deviceID].Attenuation[chnl] = -1;           // we mark the attenuation as unknown to start
        lda[deviceID].WorkingFrequency[chnl] = -1;  	// and everybody else...
        lda[deviceID].RampStart[chnl] = -1;
        lda[deviceID].RampStop[chnl] = -1;
        lda[deviceID].AttenuationStep[chnl] = -1;
        lda[deviceID].AttenuationStep2[chnl] = -1;
        lda[deviceID].DwellTime[chnl] = -1;
        lda[deviceID].DwellTime2[chnl] = -1;
        lda[deviceID].IdleTime[chnl] = -1;
        lda[deviceID].HoldTime[chnl] = -1;
        lda[deviceID].Modebits[chnl] = 0;               // Modebits aren't directly readable, but clearing them here for convenience
        lda[deviceID].ProfileDwellTime[chnl] = -1;
        lda[deviceID].ProfileIdleTime[chnl] = -1;
        lda[deviceID].ProfileCount[chnl] = -1;
    
        // clear the profile cache
        for (index = 0; index < PROFILE_MAX_RAM; index++) {
            lda[deviceID].Profile[chnl][index] = PROFILE_EMPTY;     // set all the profile elements to PROFILE_EMPTY
                                                                // Note - we only use the first 50 for HiRes devices, and the first 100 for legacy devices
        }
    }

}

/*******************************************************************************
 * \brief    Find Position of the bit set for channel mask identification
 *
 ******************************************************************************/
 // A utility function to check whether n is a power of 2 or not. 
static int isPowerOfTwo(unsigned n) 
{ 
    return n && (!(n & (n - 1))); 
} 
static int findPosition(unsigned n) 
{ 
    if (!isPowerOfTwo(n)) 
        return -1; 
  
    unsigned i = 1, pos = 1; 
  
    // Iterate through bits of n till we find a set bit 
    // i&n will be non-zero only when 'i' and 'n' have a set bit 
    // at same position 
    while (!(i & n)) { 
        // Unset current bit and set the next bit in 'i' 
        i = i << 1; 
  
        // increment position 
        ++pos; 
    } 
  
    return pos; 
} 


/*******************************************************************************
 * \brief    Parse Data Frame received from the socket
 *
 ******************************************************************************/
static int parseDataFrame(char* msg, int count, int sockfd, int devid)
{
    int i;
    int chnl;
    RESPONSE_DATA_T dataresp;
    unsigned short dataval_16;
	unsigned short prfindex;
    unsigned int dataval_32;
    unsigned char dataval_8;
	char *dataptr;
	char namebuffer[7];

#if 0
    for(i=0; i < count; i++)
    {
        if (DEBUG_OUT > 1) printf("%02X",(unsigned char)msg[i]);
    }

    if (DEBUG_OUT > 1) printf("Parse Data Frame:(Sockfd-%d, Devid-%d, Count-%d)\n",sockfd,devid,count);
#endif

    dataresp.command = msg[0];	// Command ID
    dataresp.length = msg[1];	// Data Length
    dataptr = &msg[2];			// Data buffer Start
    dataval_16 = *(unsigned short*)&msg[2];	// Data of 16 bits
    dataval_32 = *(unsigned int*)&msg[2];	// Data of 32 bits
    dataval_8 =  *(unsigned char*)&msg[2];	// Data of 8bits 

	// The reports don't carry a channel address so we use the global channel setting
	if ((lda[devid].HaveNumChannels) || (lda[devid].NumChannels != 0))
	{	
		if(lda[devid].Channel < lda[devid].NumChannels)
    		chnl = lda[devid].Channel;
		else
			chnl = lda[devid].NumChannels - 1;
	}
	else
	{
		chnl = 0;	// we don't know how many channels the device has yet
	}

    switch(dataresp.command)
	{

        case VNX_PWR:
            lda[devid].Attenuation[chnl] = dataval_16;
            break;

        case VNX_FREQUENCY:
            lda[devid].WorkingFrequency[chnl] = dataval_32;
            break;

        case VNX_SWEEP:
			// merge in the ramp mode bits from the device
			lda[devid].Modebits[chnl] = lda[devid].Modebits[chnl] & (~0xff);
            lda[devid].Modebits[chnl] |= dataval_8;
            break;

        case VNX_RFMUTE:
            if(dataval_16)
                lda[devid].Modebits[chnl] = lda[devid].Modebits[chnl] | MODE_RFON;
            else
                lda[devid].Modebits[chnl] = lda[devid].Modebits[chnl] & ~MODE_RFON;
            break;

        case VNX_ASTART:
            lda[devid].RampStart[chnl] = dataval_16;
            break;

        case VNX_ASTOP:
            lda[devid].RampStop[chnl] = dataval_16;
            break;

        case VNX_ASTEP:
            lda[devid].AttenuationStep[chnl] = dataval_16;
            break;

        case VNX_ASTEP2:
            lda[devid].AttenuationStep2[chnl] = dataval_16;
            break;

        case VNX_ADWELL:
            lda[devid].DwellTime[chnl] = dataval_32;
            break;

        case VNX_ADWELL2:
            lda[devid].DwellTime2[chnl] = dataval_32;
            break;

        case VNX_AIDLE:
            lda[devid].IdleTime[chnl] = dataval_32;
            break;

        case VNX_AHOLD:
            lda[devid].HoldTime[chnl] = dataval_32;
            break;

        case VNX_MINATTEN:
            lda[devid].MinAttenuation = dataval_16;
            break;

        case VNX_MAXATTEN:
            lda[devid].MaxAttenuation = dataval_16;
            break;

		case VNX_MAXCHANNEL:
			if (lda[devid].HaveNumChannels == 0)
			{
				if (dataval_32 <= CHANNEL_MAX)
				{
					// we have a reasonable number of channels for this device
					lda[devid].NumChannels = dataval_32;
					lda[devid].HaveNumChannels = TRUE;
				}
			}
			else
			{
				if (dataval_32 != lda[devid].NumChannels)
				{
					if (DEBUG_OUT > 0) printf("Default MaxChannel = %d, new MaxChannel = %d\n", lda[devid].NumChannels, dataval_32);
				}
			}
			
			// update the LDA-802-X name if necessary with the actual number of channels
			// it is the only LDA device with this behavior
			if ((lda[devid].DevType == LDA_802_8) && (dataval_32 != lda[devid].NumChannels))
			{
				sprintf(lda[devid].ModelName,"LDA-802-%d",lda[devid].NumChannels);
			}
			break;

        case VNX_GETSERNUM:
            lda[devid].SerialNumber = dataval_32;
            break;

			// The model name is used to identify the device type
			// The VNX_MODELNAME function returns the last 6 characters of the model name from
			// the device. We use that (or a part of it) to identify the device and set DevType
			// for non-expandable devices we set the maximum number of channels at this point
			//

        case VNX_MODELNAME:
			if (DEBUG_OUT > 1)
			{
				printf("In ModelName [packet]: ");
    			for(i = 0; i < count; i++)
    			{
        			printf("%02X ",(unsigned char)msg[i]);
    			}
				printf("\n");
			}

			// build a string from the 6 name bytes we received
			for(i = 0; i < 6; i++)
			{
				namebuffer[i] = msg[2+i];
			}
			namebuffer[6] = 0;		

			if(strstr(namebuffer,"-403"))
			{
				strcpy (lda[devid].ModelName, "LDA-403");	// save the device's model name
				if(!lda[devid].HaveNumChannels)
				{
					lda[devid].NumChannels = 1;	// this is an expandable single channel device
												// set a default
					lda[devid].BaseChannels = 1;
					lda[devid].DevType = LDA_403;
					lda[devid].MaxAttenuation = 630;	// 31.5db in .05db units
					lda[devid].MinFrequency = 10;		// 1 MHz
					lda[devid].MaxFrequency = 400000;	// 40 GHz		
				}			

                lda[devid].Expandable = true;
			}
			if(strstr(namebuffer,"-203B"))
			{
			 	strcpy (lda[devid].ModelName, "LDA-203B");
				lda[devid].DevType = LDA_203;		// the socket interface uses standard commands
				lda[devid].NumChannels = 1;
				lda[devid].HaveNumChannels = TRUE;	// no need to query for expansion channels
				lda[devid].MaxAttenuation = 1260;	// 63db in .05db units
				lda[devid].MinFrequency = 10000;	// 1 GHz
				lda[devid].MaxFrequency = 200000;	// 20 GHz

                lda[devid].Expandable = false;
			}
			if(strstr(namebuffer,"-802EH"))
			{
			 	strcpy (lda[devid].ModelName, "LDA-802EH");
				lda[devid].DevType = LDA_802EH;
				lda[devid].NumChannels = 1;
				lda[devid].HaveNumChannels = TRUE;	// no need to query for expansion channels
				lda[devid].MaxAttenuation = 2400;	// 120 db in .05db units
				lda[devid].MinFrequency = 2000;		// 200 MHz
				lda[devid].MaxFrequency = 80000;	// 8 GHz

                lda[devid].Expandable = false;
			}
			else if (strstr(namebuffer,"608V-4"))
			{
				strcpy (lda[devid].ModelName, "LDA-608V-4");
				lda[devid].DevType = LDA_608V_4;
				lda[devid].NumChannels = 4;
				lda[devid].HaveNumChannels = TRUE;	// no need to query for expansion channels
				lda[devid].MaxAttenuation = 1200;	// 60 db in .05db units
				lda[devid].MinFrequency = 2000;		// 200 MHz
				lda[devid].MaxFrequency = 80000;	// 8 GHz

                lda[devid].Expandable = false;
			}
			else if (strstr(namebuffer,"608V-2"))
			{
				strcpy (lda[devid].ModelName, "LDA-608V-2");
				lda[devid].DevType = LDA_608V_2;
				lda[devid].NumChannels = 2;
				lda[devid].HaveNumChannels = TRUE;	// no need to query for expansion channels
				lda[devid].MaxAttenuation = 1200;	// 60 db in .05db units
				lda[devid].MinFrequency = 2000;		// 200 MHz
				lda[devid].MaxFrequency = 80000;	// 8 GHz

                lda[devid].Expandable = false;
			}
			else if (strstr(namebuffer,"A-608V"))
			{
				strcpy (lda[devid].ModelName, "LDA-608V");
				lda[devid].DevType = LDA_608V;
				lda[devid].NumChannels = 1;
				lda[devid].HaveNumChannels = TRUE;	// no need to query for expansion channels
				lda[devid].MaxAttenuation = 1200;	// 60 db in .05db units
				lda[devid].MinFrequency = 2000;		// 200 MHz
				lda[devid].MaxFrequency = 80000;	// 8 GHz

                lda[devid].Expandable = false;
			}
			else if (strstr(namebuffer,"A-908V"))
			{
				strcpy (lda[devid].ModelName, "LDA-908V");	// this is the non-expandable 1 channel 908V
				lda[devid].DevType = LDA_908V;
				lda[devid].NumChannels = 1;
				lda[devid].HaveNumChannels = TRUE;	// no need to query for expansion channels
				lda[devid].MaxAttenuation = 1800;	// 90 db in .05db units
				lda[devid].MinFrequency = 2000;		// 200 MHz
				lda[devid].MaxFrequency = 80000;	// 8 GHz

                lda[devid].Expandable = false;
			}
			else if (strstr(namebuffer,"-802Q"))
			{
				strcpy (lda[devid].ModelName, "LDA-802Q");
				lda[devid].DevType = LDA_802Q;
				lda[devid].MaxAttenuation = 2400;	// 120 db in .05db units
				lda[devid].MinFrequency = 2000;		// 200 MHz
				lda[devid].MaxFrequency = 80000;	// 8 GHz
				lda[devid].BaseChannels = 4;
			 	if(!lda[devid].HaveNumChannels)
				{
					lda[devid].NumChannels = 4;	// set a default, will get updated
				}

                lda[devid].Expandable = true;
			}
			else if (strstr(namebuffer,"802-"))
			{
				lda[devid].DevType = LDA_802_8;	// preset the common case
				lda[devid].MaxAttenuation = 2400;	// 120 db in .05db units
				lda[devid].MinFrequency = 2000;		// 200 MHz
				lda[devid].MaxFrequency = 80000;	// 8 GHz

				if(lda[devid].HaveNumChannels)
				{
					// RD - the LDA-802-8 base module is the only LDA that includes
					//		expansion channel counts in the product name
					//		It is possible to have 20 channels, 24 channels, etc.
					sprintf(lda[devid].ModelName,"LDA-802-%d",lda[devid].NumChannels);
					lda[devid].BaseChannels = 8;
				}
			 	else if (strstr(namebuffer,"802-8"))
				{
					strcpy (lda[devid].ModelName, "LDA-802-8");
					lda[devid].NumChannels = 8;
					lda[devid].BaseChannels = 8;
					lda[devid].HaveNumChannels = TRUE;
				}
				else if (strstr(namebuffer,"802-12"))
				{
					// RD - the LDA-802-8 base module is the only LDA that includes
					//		expansion channel counts in the product name, so we can use them
					strcpy (lda[devid].ModelName, "LDA-802-12");
					lda[devid].NumChannels = 12;
					lda[devid].BaseChannels = 8;
					lda[devid].HaveNumChannels = TRUE;
				}
			 	else if (strstr(namebuffer,"802-16"))
				{
					strcpy (lda[devid].ModelName, "LDA-802-16");
					lda[devid].NumChannels = 16;
					lda[devid].BaseChannels = 8;
					lda[devid].HaveNumChannels = TRUE;
				}
			 	else if (strstr(namebuffer,"802-32"))
				{
					strcpy (lda[devid].ModelName, "LDA-802-32");
					lda[devid].NumChannels = 32;
					lda[devid].BaseChannels = 8;
					lda[devid].HaveNumChannels = TRUE;
				}
                else if (strstr(namebuffer,"802-40"))
				{
					strcpy (lda[devid].ModelName, "LDA-802-40");
					lda[devid].NumChannels = 40;
					lda[devid].BaseChannels = 8;
					lda[devid].HaveNumChannels = TRUE;
				}
                else if (strstr(namebuffer,"802-48"))
				{
					strcpy (lda[devid].ModelName, "LDA-802-48");
					lda[devid].NumChannels = 48;
					lda[devid].BaseChannels = 8;
					lda[devid].HaveNumChannels = TRUE;
				}
				else if (strstr(namebuffer,"802-4"))    // this needs to be after the 48 check
				{
					strcpy (lda[devid].ModelName, "LDA-802-4");
					lda[devid].NumChannels = 4;
					lda[devid].BaseChannels = 4;
					lda[devid].HaveNumChannels = TRUE;
				}
                else if (strstr(namebuffer,"802-56"))
				{
					strcpy (lda[devid].ModelName, "LDA-802-56");
					lda[devid].NumChannels = 56;
					lda[devid].BaseChannels = 8;
					lda[devid].HaveNumChannels = TRUE;
				}
                else if (strstr(namebuffer,"802-64"))
				{
					strcpy (lda[devid].ModelName, "LDA-802-64");
					lda[devid].NumChannels = 64;
					lda[devid].BaseChannels = 8;
					lda[devid].HaveNumChannels = TRUE;
				}
				else
				{
					// we can end up here if the HW has another number of channels
					// and the max channel query has not run yet
					strcpy (lda[devid].ModelName, "LDA-802-N");
					lda[devid].BaseChannels = 8;
				}				

                lda[devid].Expandable = true;
			}
			else if (strstr(namebuffer,"X1-752"))
			{
				// RD possible future HW product, not available yet
				strcpy (lda[devid].ModelName, "LDA-8X1-752");
				lda[devid].DevType = LDA_8X1_752;
				lda[devid].MaxAttenuation = 1800;	// 90 db in .05db units
				lda[devid].MinFrequency = 5000;		// 500 MHz
				lda[devid].MaxFrequency = 60000;	// 6 GHz
				lda[devid].BaseChannels = 8;
			 	if(!lda[devid].HaveNumChannels)
				{
					lda[devid].NumChannels = 8;	// set a default, will get updated
				}

                lda[devid].Expandable = true;
			}
			else if (strstr(namebuffer,"908V-"))
			{
				// The LDA-908V-N devices have an expansion bus, but they do not update
				// their name to reflect the total number of channels
				lda[devid].MaxAttenuation = 1800;	// 90 db in .05db units
				lda[devid].MinFrequency = 2000;		// 200 MHz
				lda[devid].MaxFrequency = 80000;	// 8 GHz

				if (strstr(namebuffer,"908V-4"))
				{
					strcpy (lda[devid].ModelName, "LDA-908V-4");
					lda[devid].DevType = LDA_908V_4;
					lda[devid].BaseChannels = 4;
					if(!lda[devid].HaveNumChannels)
					{
						lda[devid].NumChannels = 4; // set a default, will get updated
					}
				}
			 	else if (strstr(namebuffer,"908V-8"))
				{
					strcpy (lda[devid].ModelName, "LDA-908V-8");
					lda[devid].DevType = LDA_908V_8;
					lda[devid].BaseChannels = 8;
					if(!lda[devid].HaveNumChannels)
					{
						lda[devid].NumChannels = 8; // set a default, will get updated
					}
				}
				else if (strstr(namebuffer,"908V-2"))
				{
					strcpy (lda[devid].ModelName, "LDA-908V-2");
					lda[devid].DevType = LDA_908V_2;
					lda[devid].BaseChannels = 2;
					if(!lda[devid].HaveNumChannels)
					{
						lda[devid].NumChannels = 2; // set a default, will get updated
					}
				}
				else
				{
					// we should not end up here, if so we got a name we didn't expect
					strcpy (lda[devid].ModelName, "LDA-908V-N");
					lda[devid].BaseChannels = 8;
					lda[devid].DevType = 0;
				}

                lda[devid].Expandable = true;
			}
			else
			{
				// RD!! - we should flag this error, for now its just a super-device
				strncpy (lda[devid].ModelName, namebuffer, 6);  // save the device's model name
				lda[devid].DevType = 0;
				lda[devid].NumChannels = 32;
				lda[devid].BaseChannels = 8;
				lda[devid].MaxAttenuation = 2400;	// 120 db in .05db units
				lda[devid].MinFrequency = 1000;		// 100 MHz
				lda[devid].MaxFrequency = 400000;	// 40 GHz
			}

			// set a few parameters for the device
			lda[devid].MinAttenuation = 0;
            lda[devid].ProfileMaxLength = 1000;

			if (DEBUG_OUT > 2) printf("Exiting ModelName...\n");
            break;

        case VNX_SWVERSION:
			// build a string from the 6 bytes we received
			for(i = 0; i < 6; i++)
			{
				lda[devid].Swversion[i] = msg[2+i];		// safe copy...
			}
			lda[devid].Swversion[6] = 0;				// the null terminator for the string	
            break;
            
        case VNX_IPMODE:
            lda[devid].ipmode = (int)dataval_8;
            break;

        case VNX_IPADDR:
            sprintf(lda[devid].ipaddress, "%d.%d.%d.%d", (dataval_32 >> 24) & 0xff, (dataval_32 >> 16) & 0xff,
                 (dataval_32 >> 8) & 0xff, dataval_32 & 0xff);
            break;

        case VNX_IPMASK:
            sprintf(lda[devid].netmask, "%d.%d.%d.%d", (dataval_32 >> 24) & 0xff, (dataval_32 >> 16) & 0xff,
                 (dataval_32 >> 8) & 0xff, dataval_32 & 0xff);
            break;

        case VNX_IPGW:
            sprintf(lda[devid].gateway, "%d.%d.%d.%d", (dataval_32 >> 24) & 0xff, (dataval_32 >> 16) & 0xff,
                 (dataval_32 >> 8) & 0xff, dataval_32 & 0xff);
            break;

        case VNX_MINFREQUENCY:
            lda[devid].MinFrequency = dataval_32;
            break;

        case VNX_MAXFREQUENCY:
            lda[devid].MaxFrequency = dataval_32;
            break;

        case VNX_CHANNEL:
            lda[devid].Channel = (int)dataval_8 - 1;	// The global channel number, 1 to NumChannels
														// internally we use zero based channel numbers
			if ((lda[devid].Channel >= lda[devid].NumChannels) || (lda[devid].Channel < 0))
			{
				lda[devid].Channel = lda[devid].NumChannels - 1;	// clip to protect our arrays...
			}
            break;

        case VNX_PROFILECOUNT:
            lda[devid].ProfileCount[chnl] = dataval_16;
            break;

        case VNX_PROFILEDWELL:
            lda[devid].ProfileDwellTime[chnl] = dataval_32;
            break;

        case VNX_PROFILEIDLE:
            lda[devid].ProfileIdleTime[chnl] = dataval_32;
            break;

        case VNX_SETPROFILE:
			prfindex = *(unsigned short*)&msg[6];   // Data of 16 bits
			if (prfindex < PROFILE_MAX_RAM) 		// defend our array
			{
            	lda[devid].Profile[chnl][prfindex] = dataval_16;
			}
            break;

        default:
            break;
    }

    lda[devid].responseready = 1;  // Device Response Received

    return STATUS_OK;
}

/*******************************************************************************
 * \brief    Reads Data from the socket
 ******************************************************************************/
static int readdatafromSock(int sockfd, int devid)
{
    int count;
    char *buf_pr;
    char buf_st[512] = {0};
    int index;

    buf_pr = buf_st;
        
    if ((count = read(sockfd, buf_pr, 512)) >= 0) {

        if (DEBUG_OUT > 1) printf("READ FROM SOCKET(%d): Count-%d\n", sockfd, count);

        // Check Socket data response > 8 then split into 8 bytes chunks and parse the command data
        if(count > HID_REPORT_LENGTH)
        {
            for(index=0; index < count; index+=8)
            {
                if (DEBUG_OUT > 1) printf("Send Frame Data(%d,%d)\n",index, count);
                parseDataFrame(buf_pr+index, 8, sockfd, devid);
            }
        }
        else
            parseDataFrame(buf_pr, count, sockfd, devid);
    }
    return 0;
}

/*******************************************************************************
 * \brief    Callback for Receiver data handler of thread
 * NB -- the threadID is just an integer ID, not a pointer, it is just smuggled in
 *       as if it was a pointer
 ******************************************************************************/
static void *rxdatahandler_callback (void *threadID) {
    int tid, ret = 0;;
    struct pollfd poll_fd[1];
    tid = (int)(uintptr_t)threadID;

    if (DEBUG_OUT > 1) printf("Thread Callback:%d\n",tid);

    poll_fd[0].fd = lda[tid].devicesockfd;
    poll_fd[0].events = POLLIN | POLLRDNORM;
    poll_fd[0].revents = 0;

    while (__atomic_load_n(&stop_thread[tid], __ATOMIC_SEQ_CST) == 0) {
        // poll for reading responses
        ret = poll(poll_fd, 1, -1);
        if (ret > 0)
        {
            if (poll_fd[0].revents & (POLLIN | POLLRDNORM))
            {
                poll_fd[0].revents = 0;
                // Read data
                readdatafromSock(lda[tid].devicesockfd, tid);
            }
        }
    }

    // thread termination flag received
    __atomic_store_n(&thread_running[tid], 0, __ATOMIC_SEQ_CST);
    return 0;
}

//*****************************************************************************
//
// Function call to Set channel# to the device
// Channel is 1 to N at the API level, 0 to N-1 internally
//
// RD 7/12/24 changed to use a more backwards compatible addressing command format
//            with a goal of implementing full addressing in commands in the future
//  
//*****************************************************************************
static int SetChannel(char* deviceip, int channel)
{
    int devid = 0;
	char VNX_command[] = { 0, 0, 0, 0, 0, 0 };

    devid = GetDeviceID(deviceip);
	if (devid < 0) return STATUS_ERROR;

    if (!isDeviceSockOpen(deviceip)) return STATUS_ERROR;
	
	if ((channel < 1) || (channel > lda[devid].NumChannels)) return STATUS_ERROR;

    if (lda[devid].NumChannels < 2) {  // Devices with only 1 channel will break out here since it is a valid command and channel selection but no action is needed.
	    return STATUS_OK;
    }

	// internally we use a zero based channel number
	lda[devid].Channel = channel - 1;

	if (TestMode)
	{
		// RD - no need to emulate the mask bits...
		return STATUS_OK;
	}
        
    // convert to our mask form, and save that and our local zero based channel number
	// the mask based address consists of two bank bits and an 8 bit wide mask. Each logical bank
	// has 8 channels.
	// The global channel number, used for channels in the expansion devices, runs 1 to N
	lda[devid].ChMask = 0x01 << ((channel - 1) % 8);	// logical channel selection mask
	lda[devid].ChBank = (channel - 1) / 8;				// internally ChBank is zero based

	// no need to send set channel commands to a single channel device
	if (lda[devid].NumChannels == 1) return STATUS_OK;

	// VNX_command[5] = (char)lda[devid].ChMask;
	// VNX_command[4] = (char)(lda[devid].ChBank + 1);		// RD - this is the full bank/mask addressing
	// RD 7-12-24 not all HW supports the full bank/mask addressing, use one of the legacy
	//            channel address models
	//
    
    if (lda[devid].Expandable && (channel > (lda[devid].BaseChannels))) {
		// the channel is located on an expansion module so we use the new format command
		VNX_command[0] = (char)channel;
    }
    else {
        // convert to our mask form and save the mask
        VNX_command[5] = (char)lda[devid].ChMask;
    }
           
	if (!SendReport(devid, VNX_CHANNEL | VNX_SET, VNX_command, 6))
		return STATUS_ERROR;

    return STATUS_OK;
}

//***************************************************************************
//
// Function call to Get the parameter from the device using message
//  
//*****************************************************************************
static bool GetParameter(char* deviceip, int GetParam)
{
    char VNX_param[6] = {0, 0, 0, 0, 0, 0};
    int devid=0;

    devid = GetDeviceID(deviceip);

    if (devid >= 0)
    {
        // Check Device open or not
        if (!isDeviceSockOpen(deviceip))
            return STATUS_ERROR;

		// for test mode we don't have to do anything
		if (TestMode) return STATUS_OK;

        if (!SendReport(devid, GetParam, VNX_param, 0)) {
          return STATUS_ERROR;
        }       
    }
    else 
        return STATUS_ERROR;
    return  STATUS_OK;
}

//***************************************************************************
//
// Function call to Get the parameter from the device using message
//  
//*****************************************************************************
static bool GetParameterWithIndex(char* deviceip, int GetParam, int index)
{
    char VNX_param[6] = {0, 0, 0, 0, 0, 0};
    int devid=0;

    devid = GetDeviceID(deviceip);

    if (devid >= 0)
    {
        // Check Device open or not
        if (!isDeviceSockOpen(deviceip))
            return STATUS_ERROR;

		// for test mode we don't have to do anything
		if (TestMode) return STATUS_OK;

			VNX_param[3] = ((index >> 8) & 0x03);
			VNX_param[4] = index;
        if (!SendReport(devid, GetParam, VNX_param, 5)) {
          return STATUS_ERROR;
        }       
    }
    else 
        return STATUS_ERROR;
    return  STATUS_OK;
}


bool StartSockReadThread(DEVID deviceID)
{
    int err;

    // NOTE: vnxDeviceOpen handles starting up the socket connection
    // this function just starts the read thread
    
    pthread_mutex_lock(&dev_init_locks[deviceID]);

    // Create a device threads for reading the data from the device using sockets
    // We don't need to create a new thread if there is already one running
    if (__atomic_load_n(&thread_running[deviceID], __ATOMIC_SEQ_CST) == 0)
    {
        __atomic_store_n(&stop_thread[deviceID], 0, __ATOMIC_SEQ_CST);
        __atomic_store_n(&thread_running[deviceID], 1, __ATOMIC_SEQ_CST);
        err = pthread_create(&threads[deviceID], NULL, rxdatahandler_callback, (void*)(uintptr_t)deviceID);
        if (err != 0)
        {
            // create thread failed
            if (DEBUG_OUT > 2) printf("pthread_create failed (%d)\n", err);
            __atomic_store_n(&thread_running[deviceID], 0, __ATOMIC_SEQ_CST);
            pthread_mutex_unlock(&dev_init_locks[deviceID]);
            return FALSE;
        }
    }
    else
    {
        if (DEBUG_OUT > 2) printf("Read thread already active for device %d\n", deviceID);
    }

    pthread_mutex_unlock(&dev_init_locks[deviceID]);
    return TRUE;
}

bool StopSockReadThread(DEVID deviceID)
{
    int timedout, result;
    time_t closetime;

    pthread_mutex_lock(&dev_init_locks[deviceID]);

    // set the flag to stop the thread
    // this MUST happen before closing down the socket connection
    __atomic_store_n(&stop_thread[deviceID], 1, __ATOMIC_SEQ_CST);

    // now close down the socket connection
    shutdown(lda[deviceID].devicesockfd, SHUT_RDWR);
    result = close(lda[deviceID].devicesockfd);
    if (DEBUG_OUT > 0) printf("After close Result: %d, Socketfd:%d\n", result, lda[deviceID].devicesockfd);
    lda[deviceID].devicesockfd = 0;

    // thread exit detection
    closetime = time(NULL);
    timedout = 0;

    // wait until the thread signals exit or 3 seconds have gone by
    while ((__atomic_load_n(&thread_running[deviceID], __ATOMIC_SEQ_CST) != 0) && (0 == timedout)) {
        sleep_ms(10);   // yield for 10 ms, speed matters here
        if ((time(NULL) - closetime) > 3) timedout = 1;
    }

    if (timedout)
    {
        // ensure that the thread running flag and tid are null, just in case
        // not much we can do other than prevent this from blocking off our library from creating a new read thread the next time we try to open this device
        __atomic_store_n(&thread_running[deviceID], 0, __ATOMIC_SEQ_CST);
        threads[deviceID] = 0;

        
        pthread_mutex_unlock(&dev_init_locks[deviceID]);
        return FALSE;
    }

    
    threads[deviceID] = 0;
    pthread_mutex_unlock(&dev_init_locks[deviceID]);
    return TRUE;
}


//***************************************************************************
//
// Function call to Initialize all the library data structures with default data
//  
//*****************************************************************************
void fnLDA_Init(void) {
    /* clear out the storage structure. Must be called once before anything else */
    int index,index2;
     
    for (index = 0; index<MAXDEVICES; index++){
        ClearDevCache(index, CHANNEL_MAX);  // clear all cached variables to the unknown state

        lda[index].SerialNumber = 0;        // clear the serial number
        lda[index].ModelName[0] = 0;        // put a null string in each model name field
        lda[index].devicesockfd = 0;        // clear the device handles
		lda[index].HaveNumChannels = FALSE;	// we don't know how many channels the device has
        lda[index].deviceready = 0;			// its definitely not ready
        lda[index].responseready = 0;       // Device Response ready status  
        strcpy(lda[index].deviceip, "");
    }

    if (DEBUG_OUT > 0)  printf("Linux SDK version %s\r\n", fnLDA_LibVersion());
}

//***************************************************************************
//
// Function call to Initialize the LDA Device and Open the socket connection
// to that device for communication
//
//	RD 5/24 lots of changes. Active handles now start at 1, so the array is now
//			one element larger. The test mode device lives at array entry zero.
//  
//*****************************************************************************
STATUS_REPORT_T fnLDA_InitDevice(char* deviceip) {
    int sockfd;
    int devid, err;
    unsigned int i;

    // Check whether we reached max device count
    if ((ldadevcount >= MAXDEVICES)) {
		// no room in our table, not much we can do        
		return STATUS_ERROR;
    }

    //check device ip format 
    if(!is_valid_ip(deviceip))
        return STATUS_ERROR;

    // Check whether already the socket open for that device
    // if yes then we will simply close and proceed with the re-open of the device
    if (isDeviceSockOpen(deviceip))
        fnLDA_CloseDevice(deviceip);

	// this is a new IP address, we need to find a slot to park it in,
	// our handles start at 0
    devid = 0;  // protect our arrays
	for (i = 0; i < MAXDEVICES; i++)
	{
		if (lda[i].deviceip[0] == 0)		// a quick test for a null string
		{
			devid = i;
			break;
		}
	}
    if (i == MAXDEVICES)
        return STATUS_ERROR;    // we did not find a place for this device, bail out

    // Copy the device IP to the data structure
    strcpy(lda[devid].deviceip, deviceip);

   	if (TestMode)
	{    
       	lda[devid].devicesockfd = 1234;

		// create a fake LDA-802-8
		strcpy (lda[devid].ModelName, "LDA-802-8");
        strcpy (lda[devid].ipaddress, deviceip);
        strcpy (lda[devid].netmask, "0.0.0.0");
        strcpy (lda[devid].gateway, "0.0.0.0");
		lda[devid].DevType = LDA_802_8;
		lda[devid].SerialNumber = 12001 + devid;
		lda[devid].MaxAttenuation = 2400;		// 120 db in .05db units
		lda[devid].MinFrequency = 2000;			// 200 MHz
		lda[devid].MaxFrequency = 80000;		// 8 GHz
		lda[devid].NumChannels = 8;
		lda[devid].HaveNumChannels = TRUE;
		lda[devid].MinAttenuation = 0;
		lda[devid].ProfileMaxLength = 1000;
		lda[devid].Channel = 0;					// we start on channel 1
        for (i = 0; i < 8; i++)
        {
            lda[devid].Attenuation[i] = 0;			// 0 db attenuation
            lda[devid].WorkingFrequency[i] = 10000;	// 1 GHz working frequency
            lda[devid].RampStart[i] = 500;			// 25 db ramp start
            lda[devid].RampStop[i] = 1000;			// 50 db ramp end
            lda[devid].AttenuationStep[i] = 20;     // 1 db ramp step size for the first phase of the ramp
            lda[devid].AttenuationStep2[i] = 40;    // 2 db ramp step size for second phase of the ramp
            lda[devid].DwellTime[i] = 1000;			// 1 sec per step for the first phase of the ramp
            lda[devid].DwellTime2[i] = 500;			// 500 msec per step for the second phase of the ramp
            lda[devid].IdleTime[i] = 100;			// 100 msec idle time between ramp repeats
            lda[devid].HoldTime[i] = 200;			// 200 msec hold time between phases
            lda[devid].ProfileCount[i] = 2;			// 2 elements in the profile
            lda[devid].ProfileDwellTime[i] = 1200;	// 1.2 sec profile dwell time
            lda[devid].ProfileIdleTime[i] = 0;		// no idle time for repeating profiles
            lda[devid].Profile[i][0] = 600;			// 30 db first profile element
            lda[devid].Profile[i][1] = 400;			// 20 db first profile element
        }
   	}
    else {

        // Go ahead and open a handle to the hardware
        sockfd = vnxDeviceOpen(deviceip);
        if (sockfd == -1)  // vnxDeviceOpen returns 0 (STATUS_OK) if the open succeeded, otherwise an error code
        {         
            // our open failed, so clean up the slot we tried to use
            shutdown(lda[devid].devicesockfd, SHUT_RDWR);
            close(lda[devid].devicesockfd);
            lda[devid].devicesockfd = 0;		// RD -- redundant, but fast...
            strcpy(lda[devid].deviceip, "");
            return STATUS_ERROR;
        }
        lda[devid].devicesockfd = sockfd;

        if (DEBUG_OUT > 0) printf("Device Opened: Devid: %d, Socketfd: %d, DevCount: %d\n",devid, sockfd, ldadevcount);
    
        if (!StartSockReadThread(devid))
        {
            if (DEBUG_OUT > 2) printf("Failed to start socket read thread...\n");
            // try to shut down the read thread regardless just in case
            // this also handles shutting down the socket connection
            StopSockReadThread(devid);
            strcpy(lda[devid].deviceip, "");
            return STATUS_ERROR;
        }


        // RD!! - nobody reads the cached values, and lots of code opens and closes the device
        //		  at high rates. This code just generated traffic and slows performance for no purpose
        //		  The replacement gets the parameters we need to have - device type, number of channels, 
        //		  and current channel.

    #if 0
        // Get the current status details of the device parameter
        for(index=0; index < sizeof(STATUS_QUERY_ID); index++)
        {
            GetParameter(deviceip, STATUS_QUERY_ID[index]);
        }
    #endif

        // determine what device we have. This process also sets the DevType and NumChannels
        // for devices where the number of channels is not expandable.
        if (GetParameter(deviceip, VNX_MODELNAME))
        {
            StopSockReadThread(devid);
            strcpy(lda[devid].deviceip,"");
            return STATUS_ERROR;
        }

        // for expandable devices determine how many channels are present
        if (!lda[devid].HaveNumChannels)
        {
            if (GetParameter(deviceip, VNX_MAXCHANNEL))
            {
                StopSockReadThread(devid);
                strcpy(lda[devid].deviceip,"");
                return STATUS_ERROR;
            }
        }

        // find out what the device's active channel is
        if (lda[devid].NumChannels > 1)
        {
            // once we have the number of channels and the active channel
            // we are ready to roll
            if (GetParameter(deviceip, VNX_CHANNEL))
            {
                StopSockReadThread(devid);
                strcpy(lda[devid].deviceip,"");
                return STATUS_ERROR;
            }
        }
    } // end of real device open process case

    // if we got here everything worked OK
    ldadevcount++;
    lda[devid].deviceready = 1;
    return STATUS_OK;
}


//***************************************************************************
//
// Function call to close the socket of the device open
//  
//*****************************************************************************
STATUS_REPORT_T fnLDA_CloseDevice(char* deviceip) {
    int sockfd, devid;
	int result;
        
    //check device ip format 
    if(!is_valid_ip(deviceip))
        return STATUS_ERROR;

    devid = GetDeviceID(deviceip);

    if(devid >= 0)
    {
        // Check ready flag to see if we have been successfully initialized first
        if (lda[devid].deviceready)
        {
            // clear the stored data from this device
            strcpy(lda[devid].deviceip,"");
            lda[devid].HaveNumChannels = 0;

            lda[devid].DevType = 0;
            lda[devid].deviceready = 0;
            lda[devid].responseready = 0;

            ClearDevCache(devid, lda[devid].NumChannels);  // clear the cached variables to the unknown state
            lda[devid].NumChannels = 0;

            ldadevcount--;
            if (!TestMode){
                // shut down the socket read thread
                // this also handles shutting down the socket connection
                if (!StopSockReadThread(devid))
                {
                    if (DEBUG_OUT > 2) printf("Failed to stop socket read thread...\n");
                    return STATUS_ERROR;
                }
            }
            else
            {
                // we just need to clear devicesockfd in test mode
                lda[devid].devicesockfd = 0;
            }
        
        }
        else
            return STATUS_ERROR;
    }
    else
        return STATUS_ERROR;

  return STATUS_OK;

}


//***************************************************************************
//
// Function call to Check if the LDA Device is ready or not
//  
//*****************************************************************************
STATUS_REPORT_T fnLDA_CheckDeviceReady(char* deviceip ) {
    int devid=0;
    if (!isDeviceSockOpen(deviceip))
        return STATUS_ERROR;

    devid = GetDeviceID(deviceip);

    if (DEBUG_OUT > 1) printf("in checkdeviceready devid =  %d, deviceready = %d\n", devid, lda[devid].deviceready);

    // check if this device is ready 
    if((devid >= 0) && (lda[devid].deviceready != 0))
    {
        return STATUS_OK;
    }
    else
        return STATUS_ERROR;
}

//***************************************************************************
//
// Function call to Get Maxchannels from the device
//  
//*****************************************************************************
STATUS_REPORT_T fnLDA_GetMaxChannels(char* deviceip, int* respdata){
    int devid=0;
    if (!isDeviceSockOpen(deviceip))
        return STATUS_ERROR;

    devid = GetDeviceID(deviceip);

    // If Device exists then read the data 
    if(devid >= 0)
    {
        GetParameter(deviceip, VNX_MAXCHANNEL);
        *respdata = lda[devid].NumChannels;
    }
    else
        return STATUS_ERROR;
    return STATUS_OK;
}


//***************************************************************************
//
// Function call to Get Model name from the device
//  
//*****************************************************************************
STATUS_REPORT_T fnLDA_GetModelName(char* deviceip, char *ModelName) {
    int devid=0;
    if (!isDeviceSockOpen(deviceip))
        return STATUS_ERROR;

    devid = GetDeviceID(deviceip);

    // If Device exists then read the data 
    if(devid >= 0)
    {
        GetParameter(deviceip, VNX_MODELNAME);
        strcpy(ModelName, lda[devid].ModelName);
    }
    else
        return STATUS_ERROR;
    return STATUS_OK;
}

//***************************************************************************
//
// Function call to Get Serial# from the device
//  
//*****************************************************************************
STATUS_REPORT_T fnLDA_GetSerialNumber(char* deviceip, int* respdata){
    int devid=0;
    if (!isDeviceSockOpen(deviceip))
        return STATUS_ERROR;

    devid = GetDeviceID(deviceip);

    // If Device exists then read the data 
    if(devid >= 0)
    {
        GetParameter(deviceip, VNX_GETSERNUM);
        *respdata = lda[devid].SerialNumber;
    }
    else
        return STATUS_ERROR;
    return STATUS_OK;
}

//***************************************************************************
//
// Function call to Get Software Version from the device
//  
//*****************************************************************************
STATUS_REPORT_T fnLDA_GetSoftwareVersion(char* deviceip, char* respdata){
    int devid=0;
    if (!isDeviceSockOpen(deviceip))
        return STATUS_ERROR;

    devid = GetDeviceID(deviceip);

    // If Device exists then read the data 
    if(devid >= 0)
    {
        GetParameter(deviceip, VNX_SWVERSION);
        strcpy(respdata, lda[devid].Swversion);
    }
    else
        return STATUS_ERROR;
    return STATUS_OK;
}

//***************************************************************************
//
// Function call to Get IP Mode from the device
//  
//*****************************************************************************
STATUS_REPORT_T fnLDA_GetIPMode(char* deviceip, int* respdata){
    int devid=0;
    if (!isDeviceSockOpen(deviceip))
        return STATUS_ERROR;

    devid = GetDeviceID(deviceip);

    // If Device exists then read the data 
    if(devid >= 0)
    {
        GetParameter(deviceip, VNX_IPMODE);
        *respdata = lda[devid].ipmode;
    }
    else
        return STATUS_ERROR;
    return STATUS_OK;
}

//***************************************************************************
//
// Function call to Get IP Address from the device
//  
//*****************************************************************************
STATUS_REPORT_T fnLDA_GetIPAddress(char* deviceip, char* respdata){
    int devid=0;
    if (!isDeviceSockOpen(deviceip))
        return STATUS_ERROR;

    devid = GetDeviceID(deviceip);

    // If Device exists then read the data 
    if(devid >= 0)
    {
        GetParameter(deviceip, VNX_IPADDR);
        strcpy(respdata, lda[devid].ipaddress);
    }
    else
        return STATUS_ERROR;
    return STATUS_OK;
}

//***************************************************************************
//
// Function call to Get Netmask from the device
//  
//*****************************************************************************
STATUS_REPORT_T fnLDA_GetNetmask(char* deviceip, char* respdata){
    int devid=0;
    if (!isDeviceSockOpen(deviceip))
        return STATUS_ERROR;

    devid = GetDeviceID(deviceip);

    // If Device exists then read the data 
    if(devid >= 0)
    {
        GetParameter(deviceip, VNX_IPMASK);
        strcpy(respdata, lda[devid].netmask);
    }
    else
        return STATUS_ERROR;
    return STATUS_OK;
}

//***************************************************************************
//
// Function call to Get Gateway from the device
//  
//*****************************************************************************
STATUS_REPORT_T fnLDA_GetGateway(char* deviceip, char* respdata){
    int devid=0;
    if (!isDeviceSockOpen(deviceip))
        return STATUS_ERROR;

    devid = GetDeviceID(deviceip);

    // If Device exists then read the data 
    if(devid >= 0)
    {
        GetParameter(deviceip, VNX_IPGW);
        strcpy(respdata, lda[devid].gateway);
    }
    else
        return STATUS_ERROR;
    return STATUS_OK;
}

//***************************************************************************
//
// Function call to Get current Frequency from the device
//  
//*****************************************************************************
STATUS_REPORT_T fnLDA_GetWorkingFrequency(char* deviceip, int* respdata){
    int ch, devid=0;
    if (!isDeviceSockOpen(deviceip))
        return STATUS_ERROR;

    devid = GetDeviceID(deviceip);

    // If Device exists then read the data 
    if(devid >= 0)
    {
        GetParameter(deviceip, VNX_FREQUENCY);
		if(lda[devid].Channel < CHANNEL_MAX)
			ch = lda[devid].Channel;
		else 
			ch = CHANNEL_MAX-1;
        *respdata = lda[devid].WorkingFrequency[ch];
    }
    else
        return STATUS_ERROR;
    return STATUS_OK;
}

//***************************************************************************
//
// Function call to Get Min Frequency from the device
//  
//*****************************************************************************
STATUS_REPORT_T fnLDA_GetMinWorkingFrequency(char* deviceip, int* respdata){
    int devid=0;
   if (!isDeviceSockOpen(deviceip))
        return STATUS_ERROR;

    devid = GetDeviceID(deviceip);

    // If Device exists then read the data 
    if(devid >= 0)
    {
        GetParameter(deviceip, VNX_MINFREQUENCY);
        *respdata = lda[devid].MinFrequency; 
    }
    else
        return STATUS_ERROR;
    return STATUS_OK;
}

//***************************************************************************
//
// Function call to Get Max Frequency from the device
//  
//*****************************************************************************
STATUS_REPORT_T fnLDA_GetMaxWorkingFrequency(char* deviceip, int* respdata){
    int devid=0;
    if (!isDeviceSockOpen(deviceip))
        return STATUS_ERROR;

    devid = GetDeviceID(deviceip);

    // If Device exists then read the data 
    if(devid >= 0)
    {
        GetParameter(deviceip, VNX_MAXFREQUENCY);
        *respdata = lda[devid].MaxFrequency; 
    }
    else
        return STATUS_ERROR;
    return STATUS_OK;
}

//***************************************************************************
//
// Function call to Get Min Attenuation from the device
//  
//*****************************************************************************
STATUS_REPORT_T fnLDA_GetMinAttenuation(char* deviceip, int* respdata){
    int devid=0;
    if (!isDeviceSockOpen(deviceip))
        return STATUS_ERROR;

    devid = GetDeviceID(deviceip);

    // If Device exists then read the data 
    if(devid >= 0)
    {
        GetParameter(deviceip, VNX_MINATTEN);
        *respdata = lda[devid].MinAttenuation; 
    }
    else
        return STATUS_ERROR;
    return STATUS_OK;
}


//***************************************************************************
//
// Function call to Get Max Attenuation from the device
//  
//*****************************************************************************
STATUS_REPORT_T fnLDA_GetMaxAttenuation(char* deviceip, int* respdata){
    int devid=0;
    if (!isDeviceSockOpen(deviceip))
        return STATUS_ERROR;

    devid = GetDeviceID(deviceip);

    // If Device exists then read the data 
    if(devid >= 0)
    {
        GetParameter(deviceip, VNX_MAXATTEN);
        *respdata = lda[devid].MaxAttenuation; 
    }
    else
        return STATUS_ERROR;
    return STATUS_OK;
}

//***************************************************************************
//
// Function call to Get current Channel from the device
//
// The internal channel number is zero based, the API channel number is 1 based
//  
//*****************************************************************************
STATUS_REPORT_T fnLDA_GetChannel(char* deviceip, int* respdata){
    int devid=0;
    if (!isDeviceSockOpen(deviceip))
        return STATUS_ERROR;

    devid = GetDeviceID(deviceip);

    // If Device exists then read the data and adjust to the API format 
    if(devid >= 0)
    {
        GetParameter(deviceip, VNX_CHANNEL);
        *respdata = (lda[devid].Channel + 1);
    }
    else
        return STATUS_ERROR;
    return STATUS_OK;
}


//***************************************************************************
//
// Function call to Get current Attenuation from the device
//  
//*****************************************************************************
STATUS_REPORT_T fnLDA_GetAttenuation(char* deviceip, int* respdata){
    int ch, devid=0;
    if (!isDeviceSockOpen(deviceip))
        return STATUS_ERROR;

    devid = GetDeviceID(deviceip);

    // If Device exists then read the data 
    if(devid >= 0)
    {
        GetParameter(deviceip, VNX_PWR);
        
		if(lda[devid].Channel < CHANNEL_MAX)
			ch = lda[devid].Channel;
		else 
			ch = CHANNEL_MAX-1;
        *respdata =lda[devid].Attenuation[ch]; 
    }
    else
        return STATUS_ERROR;
    return STATUS_OK;
}

//***************************************************************************
//
// Function call to Get Ramp Start Attenuation from the device
//  
//*****************************************************************************
STATUS_REPORT_T fnLDA_GetRampStart(char* deviceip, int* respdata){
    int ch, devid=0;
    if (!isDeviceSockOpen(deviceip))
        return STATUS_ERROR;

    devid = GetDeviceID(deviceip);

    // If Device exists then read the data 
    if(devid >= 0)
    {
        GetParameter(deviceip, VNX_ASTART);
		if(lda[devid].Channel < CHANNEL_MAX)
			ch = lda[devid].Channel;
		else 
			ch = CHANNEL_MAX-1;
        *respdata =lda[devid].RampStart[ch]; 
    }
    else
        return STATUS_ERROR;
    return STATUS_OK;
}

//***************************************************************************
//
// Function call to Get Ramp End Attenuation from the device
//  
//*****************************************************************************
STATUS_REPORT_T fnLDA_GetRampEnd(char* deviceip, int* respdata){
    int ch, devid=0;
    if (!isDeviceSockOpen(deviceip))
        return STATUS_ERROR;

    devid = GetDeviceID(deviceip);

    // If Device exists then read the data 
    if(devid >= 0)
    {
        GetParameter(deviceip, VNX_ASTOP);
		if(lda[devid].Channel < CHANNEL_MAX)
			ch = lda[devid].Channel;
		else 
			ch = CHANNEL_MAX-1;
        *respdata =lda[devid].RampStop[ch]; 
    }
    else
        return STATUS_ERROR;
    return STATUS_OK;
}

//***************************************************************************
//
// Function call to Get Dwell Time from the device
//  
//*****************************************************************************
STATUS_REPORT_T fnLDA_GetDwellTime(char* deviceip, int* respdata){
    int ch, devid=0;
    if (!isDeviceSockOpen(deviceip))
        return STATUS_ERROR;

    devid = GetDeviceID(deviceip);

    // If Device exists then read the data 
    if(devid >= 0)
    {
        GetParameter(deviceip, VNX_ADWELL);
		if(lda[devid].Channel < CHANNEL_MAX)
			ch = lda[devid].Channel;
		else 
			ch = CHANNEL_MAX-1;
        *respdata =lda[devid].DwellTime[ch]; 
    }
    else
        return STATUS_ERROR;
    return STATUS_OK;
}

//***************************************************************************
//
// Function call to Get Dwell Time two from the device
//  
//*****************************************************************************
STATUS_REPORT_T fnLDA_GetDwellTimeTwo(char* deviceip, int* respdata){
    int ch, devid=0;
    if (!isDeviceSockOpen(deviceip))
        return STATUS_ERROR;

    devid = GetDeviceID(deviceip);

    // If Device exists then read the data 
    if(devid >= 0)
    {
        GetParameter(deviceip, VNX_ADWELL2);
		if(lda[devid].Channel < CHANNEL_MAX)
			ch = lda[devid].Channel;
		else 
			ch = CHANNEL_MAX-1;
        *respdata =lda[devid].DwellTime2[ch]; 
    }
    else
        return STATUS_ERROR;
    return STATUS_OK;
}

//***************************************************************************
//
// Function call to Get Idle Time from the device
//  
//*****************************************************************************
STATUS_REPORT_T fnLDA_GetIdleTime(char* deviceip, int* respdata){
    int ch, devid=0;
    if (!isDeviceSockOpen(deviceip))
        return STATUS_ERROR;

    devid = GetDeviceID(deviceip);

    // If Device exists then read the data 
    if(devid >= 0)
    {
        GetParameter(deviceip, VNX_AIDLE);
		if(lda[devid].Channel < CHANNEL_MAX)
			ch = lda[devid].Channel;
		else 
			ch = CHANNEL_MAX-1;
        *respdata =lda[devid].IdleTime[ch]; 
    }
    else
        return STATUS_ERROR;
    return STATUS_OK;
}

//***************************************************************************
//
// Function call to Get Hold Time from the device
//  
//*****************************************************************************
STATUS_REPORT_T fnLDA_GetHoldTime(char* deviceip, int* respdata){
    int ch, devid=0;
    if (!isDeviceSockOpen(deviceip))
        return STATUS_ERROR;

    devid = GetDeviceID(deviceip);

    // If the device is available read the hold time 
    if(devid >= 0)
    {
        GetParameter(deviceip, VNX_AHOLD);
		if(lda[devid].Channel < CHANNEL_MAX)
			ch = lda[devid].Channel;
		else 
			ch = CHANNEL_MAX-1;
        *respdata =lda[devid].HoldTime[ch]; 
    }
    else
        return STATUS_ERROR;
    return STATUS_OK;
}

//***************************************************************************
//
// Function call to Get Attenuation Step Size from the device
//  
//*****************************************************************************
STATUS_REPORT_T fnLDA_GetAttenuationStep(char* deviceip, int* respdata){
    int ch, devid=0;
    if (!isDeviceSockOpen(deviceip))
        return STATUS_ERROR;

    devid = GetDeviceID(deviceip);

    // If Device exists then read the data 
    if(devid >= 0)
    {
        GetParameter(deviceip, VNX_ASTEP);
		if(lda[devid].Channel < CHANNEL_MAX)
			ch = lda[devid].Channel;
		else 
			ch = CHANNEL_MAX-1;
        *respdata =lda[devid].AttenuationStep[ch]; 
    }
    else
        return STATUS_ERROR;
    return STATUS_OK;
}

//***************************************************************************
//
// Function call to Get Attenuation Step Two Size from the device
//  
//*****************************************************************************
STATUS_REPORT_T fnLDA_GetAttenuationStepTwo(char* deviceip, int* respdata){
    int ch, devid=0;
    if (!isDeviceSockOpen(deviceip))
        return STATUS_ERROR;

    devid = GetDeviceID(deviceip);

    // If Device exists then read the data 
    if(devid >= 0)
    {
        GetParameter(deviceip, VNX_ASTEP2);
		if(lda[devid].Channel < CHANNEL_MAX)
			ch = lda[devid].Channel;
		else 
			ch = CHANNEL_MAX-1;
        *respdata =lda[devid].AttenuationStep2[ch]; 
    }
    else
        return STATUS_ERROR;
    return STATUS_OK;
}

//***************************************************************************
//
// Function call to Get RF On/Off State from the device
//  
//*****************************************************************************
STATUS_REPORT_T fnLDA_GetRF_On(char* deviceip, int* respdata){
    int ch, devid=0;
    if (!isDeviceSockOpen(deviceip))
        return STATUS_ERROR;

    devid = GetDeviceID(deviceip);

    // If Device exists then read the data 
    if(devid >= 0)
    {
        GetParameter(deviceip, VNX_RFMUTE);
        if(lda[devid].Channel < CHANNEL_MAX)
            ch = lda[devid].Channel;
        else 
            ch = CHANNEL_MAX-1;

        if (lda[devid].Modebits[ch] & MODE_RFON) 
            *respdata = 1; 
        else
            *respdata = 0; 
    }
    else
        return STATUS_ERROR;
    return STATUS_OK;
}

//***************************************************************************
//
// Function call to Get Profile Maxlength from the device
//  
//*****************************************************************************
STATUS_REPORT_T fnLDA_GetProfileMaxLength(char* deviceip, int* respdata){
    int devid=0;
    if (!isDeviceSockOpen(deviceip))
        return STATUS_ERROR;

    devid = GetDeviceID(deviceip);

    // If Device exists then read the data 
    if(devid >= 0)
    {
        *respdata =lda[devid].ProfileMaxLength; 
    }
    else
        return STATUS_ERROR;
    return STATUS_OK;
}

//***************************************************************************
//
// Function call to Get Profile Element from the device
//  
//*****************************************************************************
STATUS_REPORT_T fnLDA_GetProfileElement(char* deviceip, int index, int* respdata){
    int ch, devid=0;
    if (!isDeviceSockOpen(deviceip))
        return STATUS_ERROR;

    devid = GetDeviceID(deviceip);

    // If Device exists then read the data 
    if(devid >= 0)
    {
        GetParameterWithIndex(deviceip, VNX_SETPROFILE, index);
		if(lda[devid].Channel < CHANNEL_MAX)
			ch = lda[devid].Channel;
		else 
			ch = CHANNEL_MAX-1;
        *respdata =lda[devid].Profile[ch][index]; 
    }
    else
        return STATUS_ERROR;
    return STATUS_OK;
}

//***************************************************************************
//
// Function call to Get Profile Count from the device
//  
//*****************************************************************************
STATUS_REPORT_T fnLDA_GetProfileCount(char* deviceip, int* respdata){
    int ch, devid=0;
    if (!isDeviceSockOpen(deviceip))
        return STATUS_ERROR;

    devid = GetDeviceID(deviceip);

    // If Device exists then read the data 
    if(devid >= 0)
    {
        GetParameter(deviceip, VNX_PROFILECOUNT);
		if(lda[devid].Channel < CHANNEL_MAX)
			ch = lda[devid].Channel;
		else 
			ch = CHANNEL_MAX-1;
        *respdata = lda[devid].ProfileCount[ch];
    }
    else
        return STATUS_ERROR;
    return STATUS_OK;
}

//***************************************************************************
//
// Function call to Get Profile Dwell Time from the device
//  
//*****************************************************************************
STATUS_REPORT_T fnLDA_GetProfileDwellTime(char* deviceip, int* respdata){
    int ch, devid=0;
    if (!isDeviceSockOpen(deviceip))
        return STATUS_ERROR;

    devid = GetDeviceID(deviceip);

    // If Device exists then read the data 
    if(devid >= 0)
    {
        GetParameter(deviceip, VNX_PROFILEDWELL);
		if(lda[devid].Channel < CHANNEL_MAX)
			ch = lda[devid].Channel;
		else 
			ch = CHANNEL_MAX-1;
        *respdata =lda[devid].ProfileDwellTime[ch];
    }
    else
        return STATUS_ERROR;
    return STATUS_OK;
}

//***************************************************************************
//
// Function call to Get Profile Idle Time from the device
//  
//*****************************************************************************
STATUS_REPORT_T fnLDA_GetProfileIdleTime(char* deviceip, int* respdata){
    int ch, devid=0;
    if (!isDeviceSockOpen(deviceip))
        return STATUS_ERROR;

    devid = GetDeviceID(deviceip);

    // If Device exists then read the data 
    if(devid >= 0)
    {
        GetParameter(deviceip, VNX_PROFILEIDLE);
		if(lda[devid].Channel < CHANNEL_MAX)
			ch = lda[devid].Channel;
		else 
			ch = CHANNEL_MAX-1;
        *respdata = lda[devid].ProfileIdleTime[ch];
    }
    else
        return STATUS_ERROR;
    return STATUS_OK;
}

//***************************************************************************
//
// Function call for Get a set of bits describing the features available in this attenuator device
//  
//***************************************************************************
STATUS_REPORT_T fnLDA_GetFeatures(char* deviceip, int* respdata) {
	int licdata = DEFAULT_FEATURES;

    int ch, devid=0;
    if (!isDeviceSockOpen(deviceip))
        return STATUS_ERROR;

    devid = GetDeviceID(deviceip);

    // If Device exists then read the data 
    if(devid >= 0)
    {
		licdata = (HAS_HIRES | HAS_BIDIR_RAMPS | HAS_PROFILES);// HiRes has bidirectional ramps, profiles and HiRes

		if (lda[devid].NumChannels == 4) licdata |= HAS_4CHANNELS;
		if (lda[devid].NumChannels == 8) licdata |= HAS_8CHANNELS;
        if (lda[devid].Expandable) licdata |= HAS_MCHANNELS;
		
		licdata |= HAS_LONG_PROFILE;

		*respdata = licdata;
    }
    else {
        return STATUS_ERROR;
    }
	return STATUS_OK;
}

//*****************************************************************************
//
// Function call to Set current operating frequency to the device
//  
//*****************************************************************************
STATUS_REPORT_T fnLDA_SetWorkingFrequency(char* deviceip, int frequency) {
    int devid=0;
    int old_frequency,tmp_frequency = 0;
    int ch = 0;
    char *ptr;

    devid = GetDeviceID(deviceip);

    if( devid >=0)
    {
        // Check Device open or not
        if (!isDeviceSockOpen(deviceip))
            return STATUS_ERROR;

		if(lda[devid].Channel < CHANNEL_MAX)
			ch = lda[devid].Channel;
		else 
			ch = CHANNEL_MAX-1;

        old_frequency = lda[devid].WorkingFrequency[ch];

        if (DEBUG_OUT > 0) {
          printf("Min frequency is %d\r\n", lda[devid].MinFrequency);
          printf("Max frequency is %d\r\n", lda[devid].MaxFrequency);
          printf("User frequency to set is %d\r\n", frequency);
        }

        if ((frequency >= lda[devid].MinFrequency) && (frequency <= lda[devid].MaxFrequency)) {
          lda[devid].WorkingFrequency[ch] = frequency;
          if (TestMode)
            return STATUS_OK;       // in test mode we update our internal variables, but don't talk to the real HW
        } else {
          return STATUS_ERROR;
        }

        // the working frequency value is OK, lets send it to the hardware
        tmp_frequency = frequency;
        ptr = (char *) &tmp_frequency;

        if (DEBUG_OUT > 0) printf("setting frequency to %d\r\n", tmp_frequency);

        if (!SendReport(devid, VNX_FREQUENCY | VNX_SET, ptr, 4)) {
          lda[devid].WorkingFrequency[ch] = old_frequency;
          return STATUS_ERROR;
        }       
        return STATUS_OK;
    }
    else
        return STATUS_ERROR;
}

//*****************************************************************************
//
// Function call to Set channel# to the device
//  
//*****************************************************************************
STATUS_REPORT_T fnLDA_SetChannel(char* deviceip, int channel)
{
    return SetChannel(deviceip, channel);
}

//*****************************************************************************
//
// Function call to Set Attenuation data to the device
//  
//*****************************************************************************
STATUS_REPORT_T fnLDA_SetAttenuation(char* deviceip, int attenuation) {

    int tmp_attenuation = 0;
    int old_attenuation, devid=0;
	int ch;
    char *ptr;

    devid = GetDeviceID(deviceip);

    if( devid >=0)
    {
        // Check Device open or not
        if (!isDeviceSockOpen(deviceip))
            return STATUS_ERROR;
		if(lda[devid].Channel < CHANNEL_MAX)
			ch = lda[devid].Channel;
		else 
			ch = CHANNEL_MAX-1;
        old_attenuation = lda[devid].Attenuation[ch];
        if ((attenuation >= lda[devid].MinAttenuation) && (attenuation <= lda[devid].MaxAttenuation))
		{ 
            lda[devid].Attenuation[ch] = attenuation;
		}
        else
			return STATUS_ERROR;

        // In test mode we update our internal variables but don't talk to the hw
        if (TestMode) return STATUS_OK;

        tmp_attenuation = attenuation;
        ptr = (char *) &tmp_attenuation;

        if (DEBUG_OUT > 0) printf("setting attenuation to %d\r\n", tmp_attenuation);
        
        if (!SendReport(devid, VNX_PWR | VNX_SET, ptr, 4)) {
          lda[devid].Attenuation[ch] = old_attenuation;
          return STATUS_ERROR;
        }       
    }
    else 
        return STATUS_ERROR;
    return STATUS_OK;
}

//*****************************************************************************
//
// Function call set attenuation on multiple channels of the device 
// chmask has a 1 bit set for every channel to be set
//
// RD 5/2024 experimental code
//*****************************************************************************
STATUS_REPORT_T fnLDA_SetAttenuationMC(char* deviceip, int attenuation, int chmask)
{
    int bank, tmp;
    unsigned int ch, i;
    int devid = 0;

    devid = GetDeviceID(deviceip);
    if (devid >= 0)
    {
        // Check Device open or not
        if (!isDeviceSockOpen(deviceip))
            return STATUS_ERROR;

        char VNX_command[] = {0, 0, 0, 0, 0, 0};

		// limit the active channels based on the number of channels in the device
		tmp = 0xFFFFFFFF >> (32 - lda[devid].NumChannels);
		chmask &= tmp;	// clip off any extraneous select bits

		// make sure the attenuation value is in range for this device
        if ((attenuation >= lda[devid].MinAttenuation) && (attenuation <= lda[devid].MaxAttenuation))
		{
				// save the new attenuation values in our local cache
 				tmp = 1;
				for (i = 0; i < lda[devid].NumChannels; i++)
				{
					if (tmp & chmask)
					{
						lda[devid].Attenuation[i] = attenuation;
					}
				
					tmp = tmp << 1;
				}

 				if (TestMode) return STATUS_OK;  // for test mode we just update internal variables
		}
        else
			return STATUS_ERROR;

		// put the attenuation value into our command
		VNX_command[0] = (BYTE)(attenuation & 0x000000ff);  // low byte of attenuation in .05 db device units
        VNX_command[1] = (BYTE)((attenuation & 0x0000ff00) >> 8);   // high byte of attenuation

		// we are ready to send the multiple channel attenuation commands to the hardware
		for (i = 0; i < 4; i++)
		{
			tmp = chmask >> ((8 * i) & 0xff);
			if (tmp != 0)
			{
				// we have channels selected in this bank
				VNX_command[4] = i + 1; 
        		VNX_command[5] = (BYTE)tmp;	// the channel bit mask for this bank

        		if (!SendReport(devid , VNX_PWR | VNX_SET, (char *)VNX_command, 6))
				{
            		return STATUS_ERROR;
        		}
			}
		}
    }
    else
        return STATUS_ERROR;

    return STATUS_OK;
}

//*****************************************************************************
//
// Function call to Set Attenuation data of channel# to the device
//  
//*****************************************************************************
STATUS_REPORT_T fnLDA_SetAttenuationQ(char* deviceip, int attenuation, int channel) {

    int tmp_attenuation = 0;
    STATUS_REPORT_T SCResult;
    int devid=0;

    devid = GetDeviceID(deviceip);
    if( devid >=0)
    {
        // Check Device open or not
        if (!isDeviceSockOpen(deviceip))
            return STATUS_ERROR;

        // set the channel first
        SCResult = (STATUS_REPORT_T) SetChannel(deviceip, channel);
        if ( SCResult != STATUS_OK) return SCResult;

        fnLDA_SetAttenuation(deviceip, attenuation);
    }
    else 
        return STATUS_ERROR;
    return STATUS_OK;
}

//*****************************************************************************
//
// Function call to Set Attenuation Ramp Step Size(First Phase) to the device
//  
//*****************************************************************************
STATUS_REPORT_T fnLDA_SetAttenuationStep(char* deviceip, int attenuationstep) {
    int old_attenuationstep, tmp_attenuationstep = 0;
    int ch, devid=0;
    char *ptr;

    devid = GetDeviceID(deviceip);

    if(devid >= 0)
    {
        // Check Device open or not
        if (!isDeviceSockOpen(deviceip))
            return STATUS_ERROR;

		if(lda[devid].Channel < CHANNEL_MAX)
			ch = lda[devid].Channel;
		else 
			ch = CHANNEL_MAX-1;

        old_attenuationstep = lda[devid].AttenuationStep[ch];

        if (attenuationstep < (lda[devid].MaxAttenuation - lda[devid].MinAttenuation))
		{
            lda[devid].AttenuationStep[ch] = attenuationstep;
		}
		else
			return STATUS_ERROR;

        // In test mode we update our internal variables but don't talk to the hw
        if (TestMode) return STATUS_OK;
      
        tmp_attenuationstep = attenuationstep;
        ptr = (char *) &tmp_attenuationstep;

        if (!SendReport(devid, VNX_ASTEP | VNX_SET, ptr, 4)) {
            lda[devid].AttenuationStep[ch] = old_attenuationstep;
            return STATUS_ERROR;
        }
    }
    else
        return STATUS_ERROR;
    return STATUS_OK;
}

//*****************************************************************************
//
// Function call to Set Attenuation Ramp Step Size(Second Phase) to the device
//  
//*****************************************************************************
STATUS_REPORT_T fnLDA_SetAttenuationStepTwo(char* deviceip, int attenuationstep2) {
    int old_attenuationstep, tmp_attenuationstep = 0;
    int ch, devid = 0;
    char *ptr;

    devid = GetDeviceID(deviceip);

    if(devid >= 0)
    {
        // Check Device open or not
        if (!isDeviceSockOpen(deviceip))
            return STATUS_ERROR;

		if(lda[devid].Channel < CHANNEL_MAX)
			ch = lda[devid].Channel;
		else 
			ch = CHANNEL_MAX-1;

        old_attenuationstep = lda[devid].AttenuationStep2[ch];

        if (attenuationstep2 < (lda[devid].MaxAttenuation - lda[devid].MinAttenuation))
		{ 
            lda[devid].AttenuationStep2[ch] = attenuationstep2;
		}
		else
			return STATUS_ERROR;

        // In test mode we update our internal variables but don't talk to the hw
        if (TestMode) return STATUS_OK;
      
        tmp_attenuationstep = attenuationstep2;
        ptr = (char *) &tmp_attenuationstep;

        if (!SendReport(devid, VNX_ASTEP2 | VNX_SET, ptr, 4)) {
            lda[devid].AttenuationStep2[ch] = old_attenuationstep;
            return STATUS_ERROR;
        }
    }
    else
        return STATUS_ERROR;
    return STATUS_OK;
}

//*****************************************************************************
//
// Function call to Set Ramp Start Attenuation data to the device
//  
//*****************************************************************************
STATUS_REPORT_T fnLDA_SetRampStart(char* deviceip, int rampstart) {
    int tmp_rampstart = 0;
    int ch, old_rampstart, devid = 0;
    char *ptr;

    devid = GetDeviceID(deviceip);

    if (devid >= 0)
    {
        // Check Device open or not
        if (!isDeviceSockOpen(deviceip))
            return STATUS_ERROR;

		if (lda[devid].Channel < CHANNEL_MAX-1)
			ch = lda[devid].Channel;
		else 
			ch = CHANNEL_MAX-1;
        old_rampstart = lda[devid].RampStart[ch];

        if ((rampstart >= lda[devid].MinAttenuation) && (rampstart <= lda[devid].MaxAttenuation))
		{
            lda[devid].RampStart[ch] = rampstart;
		}
		else
			return STATUS_ERROR;

        // In test mode we update our internal variables but don't talk to the hw
        if (TestMode) return STATUS_OK;

        tmp_rampstart = rampstart;
        ptr = (char *) &tmp_rampstart;

        if (!SendReport(devid, VNX_ASTART | VNX_SET, ptr, 4)){
            lda[devid].RampStart[ch] = old_rampstart;
            return STATUS_ERROR;
        }
    }
    else 
        return STATUS_ERROR;
    return STATUS_OK;
}

//*****************************************************************************
//
// Function call to Set Ramp End Attenuation data to the device
//  
//*****************************************************************************
STATUS_REPORT_T fnLDA_SetRampEnd(char* deviceip, int rampstop) {
    int tmp_rampstop = 0;
    int ch, old_rampstop, devid = 0;
    char *ptr;

    devid = GetDeviceID(deviceip);
    if (devid >= 0)
    {
        // Check Device open or not
        if (!isDeviceSockOpen(deviceip))
            return STATUS_ERROR;

		if (lda[devid].Channel < CHANNEL_MAX-1)
			ch = lda[devid].Channel;
		else 
			ch = CHANNEL_MAX-1;

        old_rampstop = lda[devid].RampStop[ch];

        if ((rampstop >= lda[devid].MinAttenuation) && (rampstop <= lda[devid].MaxAttenuation))
		{
            lda[devid].RampStop[ch] = rampstop;
		}
		else
			return STATUS_ERROR;

        // In test mode we update our internal variables but don't talk to the hw
        if (TestMode) return STATUS_OK;

        tmp_rampstop = rampstop;
        ptr = (char *) &tmp_rampstop;

        if (!SendReport(devid, VNX_ASTOP | VNX_SET, ptr, 4)) {
            lda[devid].RampStop[ch] = old_rampstop;
            return STATUS_ERROR;
        }
    }
    else 
        return STATUS_ERROR;

    return STATUS_OK;
}

//*****************************************************************************
//
// Function call to Set Dwell Time data(First Phase Ramp) to the device
//  
//*****************************************************************************
STATUS_REPORT_T fnLDA_SetDwellTime(char* deviceip, int dwelltime) {
    int ch = 0;
    int old_dwelltime,devid = 0;
    char *ptr;

    devid = GetDeviceID(deviceip);
    if (devid >= 0)
    {
        // Check Device open or not
        if (!isDeviceSockOpen(deviceip))
            return STATUS_ERROR;

		if (lda[devid].Channel < CHANNEL_MAX-1)
			ch = lda[devid].Channel;
		else 
			ch = CHANNEL_MAX-1;

        old_dwelltime = lda[devid].DwellTime[ch];

        if (dwelltime >= VNX_MIN_DWELLTIME)
		{
            lda[devid].DwellTime[ch] = dwelltime;
		}
		else
			return STATUS_ERROR;

        // In test mode we update our internal variables but don't talk to the hw
        if (TestMode) return STATUS_OK;

        // the dwell time value is OK, lets send it to the hardware
        ptr = (char *) &lda[devid].DwellTime[ch];

        if (!SendReport(devid, VNX_ADWELL | VNX_SET, ptr, 4)) {
            lda[devid].DwellTime[ch] = old_dwelltime;
            return STATUS_ERROR;
        }
    }
    else 
        return STATUS_ERROR;

    return STATUS_OK;
}

//*****************************************************************************
//
// Function call to Set Dwell Time Two data(Second Phase Ramp) to the device
//  
//*****************************************************************************
STATUS_REPORT_T fnLDA_SetDwellTimeTwo(char* deviceip, int dwelltime2) {
    int ch = 0;
    int old_dwelltime2, devid = 0;
    char *ptr;

    devid = GetDeviceID(deviceip);
    if (devid >=0)
    {
        // Check Device open or not
        if (!isDeviceSockOpen(deviceip))
            return STATUS_ERROR;

		if (lda[devid].Channel < CHANNEL_MAX-1)
			ch = lda[devid].Channel;
		else 
			ch = CHANNEL_MAX-1;

        old_dwelltime2 = lda[devid].DwellTime2[ch];

        if (dwelltime2 >= VNX_MIN_DWELLTIME)
		{ 
            lda[devid].DwellTime2[ch] = dwelltime2;
		}
		else
			return STATUS_ERROR;

        // In test mode we update our internal variables but don't talk to the hw
        if (TestMode) return STATUS_OK;
      
        // the dwell time value is OK, lets send it to the hardware
        ptr = (char *) &lda[devid].DwellTime2[ch];

        if (!SendReport(devid, VNX_ADWELL2 | VNX_SET, ptr, 4)) {
            lda[devid].DwellTime2[ch] = old_dwelltime2;
            return STATUS_ERROR;
        }
    }
    else 
      return STATUS_ERROR;

    return STATUS_OK;
}

//*****************************************************************************
//
// Function call to Set Idle Time data(Wait time @end of Ramp) to the device
//  
//*****************************************************************************
STATUS_REPORT_T fnLDA_SetIdleTime(char* deviceip, int idletime) {
    int ch = 0;
    int old_idletime, devid = 0;
    char *ptr;

    devid = GetDeviceID(deviceip);
    if (devid >= 0)
    {
        // Check Device open or not
        if (!isDeviceSockOpen(deviceip))
            return STATUS_ERROR;

		if (lda[devid].Channel < CHANNEL_MAX-1)
			ch = lda[devid].Channel;
		else 
			ch = CHANNEL_MAX-1;

        old_idletime = lda[devid].IdleTime[ch];

        if (idletime >= 0)		// idle time can be zero
		{ 
            lda[devid].IdleTime[ch] = idletime;
		}
		else
			return STATUS_ERROR;

        // In test mode we update our internal variables but don't talk to the hw
        if (TestMode) return STATUS_OK;
     
        ptr = (char *) &lda[devid].IdleTime[ch];

        if (!SendReport(devid, VNX_AIDLE | VNX_SET, ptr, 4)) {
            lda[devid].IdleTime[ch] = old_idletime;
            return STATUS_ERROR;
        }
    }
    else 
        return STATUS_ERROR;

    return STATUS_OK;
}

//*****************************************************************************
//
// Function call to Set Hold Time data(Wait time btw First and Second Phase)
// to the device
//  
//*****************************************************************************
STATUS_REPORT_T fnLDA_SetHoldTime(char* deviceip, int holdtime) {
    int ch = 0;
    int old_holdtime, devid = 0;
    char *ptr;

    devid = GetDeviceID(deviceip);
    if (devid >=0)
    {
        // Check Device open or not
        if (!isDeviceSockOpen(deviceip))
            return STATUS_ERROR;

		if (lda[devid].Channel < CHANNEL_MAX-1)
			ch = lda[devid].Channel;
		else 
			ch = CHANNEL_MAX-1;

        old_holdtime = lda[devid].HoldTime[ch];

        if (holdtime >= 0)	// holdtime can be zero
		{
            lda[devid].HoldTime[ch] = holdtime;
		}
		else
			return STATUS_ERROR;

        // In test mode we update our internal variables but don't talk to the hw
        if (TestMode) return STATUS_OK;
     
        ptr = (char *) &lda[devid].HoldTime[ch];

        if (!SendReport(devid, VNX_AHOLD | VNX_SET, ptr, 4)) {
            lda[devid].HoldTime[ch] = old_holdtime;
            return STATUS_ERROR;
        }
    }
    else 
        return STATUS_ERROR;
  
    return STATUS_OK;
}

//*****************************************************************************
//
// Function call to Set RF On/Off state to the device (not supported by all attenuators)
//  
//*****************************************************************************
STATUS_REPORT_T fnLDA_SetRFOn(char* deviceip, bool on) {
    int ch = 0;
    int devid = 0;

    devid = GetDeviceID(deviceip);
    if (devid >= 0)
    {
        // Check Device open or not
        if (!isDeviceSockOpen(deviceip))
            return STATUS_ERROR;

		if (lda[devid].Channel < CHANNEL_MAX-1)
			ch = lda[devid].Channel;
		else 
			ch = CHANNEL_MAX-1;
    
        char VNX_command[] = {0, 0, 0, 0};

        if (on) {
            lda[devid].Modebits[ch] = lda[devid].Modebits[ch] & ~MODE_RFON;
            lda[devid].Modebits[ch] = lda[devid].Modebits[ch] | MODE_RFON;
            VNX_command[0] = 1;
        } else  {
            lda[devid].Modebits[ch] = lda[devid].Modebits[ch] & ~MODE_RFON;
            VNX_command[0] = 0;
        }

        if (TestMode) return STATUS_OK;  // for test mode we just update internal variables

        if (!SendReport(devid, VNX_RFMUTE | VNX_SET, VNX_command, 1))
          return STATUS_ERROR;
    }
    else
        STATUS_ERROR;

    return STATUS_OK;
}

//*****************************************************************************
//
// Function call to Set Ramp Direction to the device , Up = True (Upwards)
//  
//*****************************************************************************
STATUS_REPORT_T fnLDA_SetRampDirection(char* deviceip, bool up) {
    int ch = 0;
    int devid = 0;

    devid = GetDeviceID(deviceip);
    if (devid >= 0)
    {
        // Check Device open or not
        if (!isDeviceSockOpen(deviceip))
            return STATUS_ERROR;

		if (lda[devid].Channel < CHANNEL_MAX-1)
			ch = lda[devid].Channel;
		else 
			ch = CHANNEL_MAX-1;

        if (up)
        {
			// ramp direction up (bit == 0)
            lda[devid].Modebits[ch] = lda[devid].Modebits[ch] & ~SWP_DIRECTION;
        }
        else
        {
 			// ramp direction downwards
            lda[devid].Modebits[ch] = lda[devid].Modebits[ch] | SWP_DIRECTION;
        }
    }
    else
        return STATUS_ERROR;

    return STATUS_OK;
}

//*****************************************************************************
//
// Function call to Set Ramp Mode to the device , Mode = True (Repeated Ramp)
//  
//*****************************************************************************
STATUS_REPORT_T fnLDA_SetRampMode(char* deviceip, bool mode) {
    int ch = 0;
    int devid = 0;

    devid = GetDeviceID(deviceip);
    if (devid >= 0)
    {
        // Check if this device is open
        if (!isDeviceSockOpen(deviceip))
            return STATUS_ERROR;

		if (lda[devid].Channel < CHANNEL_MAX-1)
			ch = lda[devid].Channel;
		else 
			ch = CHANNEL_MAX-1;

        if (mode) {
            lda[devid].Modebits[ch] = lda[devid].Modebits[ch] | SWP_CONTINUOUS;     // Repeated ramp or sweep
            lda[devid].Modebits[ch] = lda[devid].Modebits[ch] & ~SWP_ONCE;
        } else {
            lda[devid].Modebits[ch] = lda[devid].Modebits[ch] | SWP_ONCE;           // one time ramp or sweep
            lda[devid].Modebits[ch] = lda[devid].Modebits[ch] & ~SWP_CONTINUOUS;
        }
    }
    else
        return STATUS_ERROR;

    return STATUS_OK;
}

//*****************************************************************************
//
// Function call to Set Birectional Mode to the device , bidir_enable = True (Bidirectional)
//  
//*****************************************************************************
STATUS_REPORT_T fnLDA_SetRampBidirectional(char* deviceip, bool bidir_enable) {
    int ch = 0;
    int devid = 0;

    devid = GetDeviceID(deviceip);
    if (devid >= 0)
    {
        // Check if device is open
        if (!isDeviceSockOpen(deviceip))
            return STATUS_ERROR;

		if (lda[devid].Channel < CHANNEL_MAX-1)
			ch = lda[devid].Channel;
		else 
			ch = CHANNEL_MAX-1;

        if (bidir_enable)
        {
            lda[devid].Modebits[ch] = lda[devid].Modebits[ch] | SWP_BIDIR;    // bidirectional ramp
        }
        else
        {
            lda[devid].Modebits[ch] = lda[devid].Modebits[ch] & ~SWP_BIDIR;   // unidirectional ramp
        }
    }
    else
        return STATUS_ERROR;

    return STATUS_OK;
}

//*****************************************************************************
//
// Function call to Set Profile Element data to the device
//  
//*****************************************************************************
 STATUS_REPORT_T fnLDA_SetProfileElement(char* deviceip, int index, int attenuation) {
    int ch = 0;
    int devid=0;
    int max_index, old_element;
    BYTE VNX_command[] = {0, 0, 0, 0, 0, 0, 0};
    
    devid = GetDeviceID(deviceip);
    if( devid >=0)
    {
        // Check Device open or not
        if (!isDeviceSockOpen(deviceip))
            return STATUS_ERROR;
        
		if(lda[devid].Channel < CHANNEL_MAX)
			ch = lda[devid].Channel;
		else 
			ch = CHANNEL_MAX-1;

        max_index = lda[devid].ProfileMaxLength - 1;

		if (max_index < 0 || max_index > 999) max_index = 999;		// defend our arrays

		if (index < 0 || index > max_index) return STATUS_ERROR;	// invalid profile index
        
        if ((attenuation >= lda[devid].MinAttenuation) && (attenuation <= lda[devid].MaxAttenuation))
        {
            old_element = lda[devid].Profile[ch][index];        // keep cached value in case IO fails
            lda[devid].Profile[ch][index] = attenuation;        // and stash the new value
        }
        else
            return STATUS_ERROR;

        // In test mode we update our internal variables but don't talk to the hw
        if (TestMode) return STATUS_OK;

        // HiRes LDA
        VNX_command[3] = (BYTE)((index >> 8) & 0x03);       // the two ms bits of the index
        VNX_command[4] = (BYTE)index;                       // profile element to update
        VNX_command[0] = (BYTE)(attenuation & 0x000000ff);  // low byte of attenuation in .05 db device units
        VNX_command[1] = (BYTE)((attenuation & 0x0000ff00) >> 8);   // high byte of attenuation

        if (!SendReport(devid, VNX_SETPROFILE | VNX_SET, (char *)VNX_command, 5)) {
            lda[devid].Profile[ch][index] = old_element;
            return STATUS_ERROR;
        }
    }
    else 
      return STATUS_ERROR;

    return STATUS_OK;
}

//*****************************************************************************
//
// Function call to Set Profile Count to the device
//  
//*****************************************************************************
STATUS_REPORT_T fnLDA_SetProfileCount(char* deviceip, int profilecount) {
    int ch = 0;
    int old_profilecount, devid = 0;
    int max_count;
    char *ptr;

    devid = GetDeviceID(deviceip);
    if (devid >=0)
    {
        // Check Device open or not
        if (!isDeviceSockOpen(deviceip))
            return STATUS_ERROR;

		if (lda[devid].Channel < CHANNEL_MAX-1)
			ch = lda[devid].Channel;
		else 
			ch = CHANNEL_MAX-1;

        old_profilecount = lda[devid].ProfileCount[ch];

        max_count = lda[devid].ProfileMaxLength;
        
        if (profilecount <= max_count && profilecount > 0)
		{ 
            lda[devid].ProfileCount[ch] = profilecount;
		}
		else
			return STATUS_ERROR;	// out of range count value

        // In test mode we update our internal variables but don't talk to the hw
        if (TestMode) return STATUS_OK;
      
        // the profile count value is OK, lets send it to the hardware
        ptr = (char *) &lda[devid].ProfileCount[ch];

        if (!SendReport(devid, VNX_PROFILECOUNT | VNX_SET, ptr, 4)) {
            lda[devid].ProfileCount[ch] = old_profilecount;
            return STATUS_ERROR;
        }
    }
    else 
      return STATUS_ERROR;

    return STATUS_OK;
}

//*****************************************************************************
//
// Function call to Set Profile Idle Time to the device
//  
//*****************************************************************************
STATUS_REPORT_T fnLDA_SetProfileIdleTime(char* deviceip, int idletime) {
    int ch = 0;
    int old_idletime, devid = 0;
    char *ptr;

    devid = GetDeviceID(deviceip);
    if (devid >=0)
    {
        // Check Device open or not
        if (!isDeviceSockOpen(deviceip))
            return STATUS_ERROR;

		if (lda[devid].Channel < CHANNEL_MAX-1)
			ch = lda[devid].Channel;
		else 
			ch = CHANNEL_MAX-1;

        old_idletime = lda[devid].ProfileIdleTime[ch];
        
        if (idletime >= 0)
		{ 
            lda[devid].ProfileIdleTime[ch] = idletime;
		}
		else
			return STATUS_ERROR;

        // In test mode we update our internal variables but don't talk to the hw
        if (TestMode) return STATUS_OK;
      
        // the profile idle time value is OK, lets send it to the hardware
        ptr = (char *) &lda[devid].ProfileIdleTime[ch];

        if (!SendReport(devid, VNX_PROFILEIDLE | VNX_SET, ptr, 4)) {
            lda[devid].ProfileIdleTime[ch] = old_idletime;
            return STATUS_ERROR;
        }
    }
    else 
      return STATUS_ERROR;

    return STATUS_OK;
}

//*****************************************************************************
//
// Function call to Set Profile Dwell Time to the device
//  
//*****************************************************************************
STATUS_REPORT_T fnLDA_SetProfileDwellTime(char* deviceip, int dwelltime) {
    int ch = 0;
    int old_dwelltime, devid = 0;
    char *ptr;

    devid = GetDeviceID(deviceip);
    if (devid >=0)
    {
        // Check Device open or not
        if (!isDeviceSockOpen(deviceip))
            return STATUS_ERROR;

		if (lda[devid].Channel < CHANNEL_MAX-1)
			ch = lda[devid].Channel;
		else 
			ch = CHANNEL_MAX-1;

        old_dwelltime = lda[devid].ProfileDwellTime[ch];
        
        if (dwelltime >= VNX_MIN_DWELLTIME)
		{
            lda[devid].ProfileDwellTime[ch] = dwelltime;
		}
		else
			return STATUS_ERROR;

        // In test mode we update our internal variables but don't talk to the hw
        if (TestMode) return STATUS_OK;
      
        // the profile dwell time value is OK, lets send it to the hardware
        ptr = (char *) &lda[devid].ProfileDwellTime[ch];

        if (!SendReport(devid, VNX_PROFILEDWELL | VNX_SET, ptr, 4)) {
            lda[devid].ProfileDwellTime[ch] = old_dwelltime;
            return STATUS_ERROR;
        }
    }
    else 
      return STATUS_ERROR;

    return STATUS_OK;
}

//*****************************************************************************
//
// Function call to Set Profile mode to the device and start/stop profiles
//  
//*****************************************************************************
STATUS_REPORT_T fnLDA_StartProfile(char* deviceip, int mode) {
    int devid = 0;
    BYTE VNX_command[] = {0, 0, 0, 0, 0, 0};

    devid = GetDeviceID(deviceip);
    if (devid >= 0)
    {
        // Check Device open or not
        if (!isDeviceSockOpen(deviceip))
            return STATUS_ERROR;
        
        
		if (TestMode) return STATUS_OK;	// we don't emulate ramps or profiles in test mode yet

        if (mode != 0)  // mode is 1 for a single profile, 2 for a repeating profile
        {
            VNX_command[0] = (BYTE) ((mode & 0x00000003) | STATUS_PROFILE_ACTIVE);  // start the profile
        }
        else
        {
            VNX_command[0] = 0;     // stop the profile
        }

        if (!SendReport(devid, VNX_SWEEP | VNX_SET, (char *)VNX_command, 3)) {
            return STATUS_ERROR;
        }
    }
    else 
      return STATUS_ERROR;

    return STATUS_OK;
}

//*****************************************************************************
//
// Function call to Start Ramp Mode 
//  
//*****************************************************************************
STATUS_REPORT_T fnLDA_StartRamp(char* deviceip, bool go) {
    int icount;
    int ch = 0;
    int devid = 0;

    devid = GetDeviceID(deviceip);
    if (devid >=0)
    {
        // Check Device open or not
        if (!isDeviceSockOpen(deviceip))
            return STATUS_ERROR;

		if (lda[devid].Channel < CHANNEL_MAX-1)
			ch = lda[devid].Channel;
		else 
			ch = CHANNEL_MAX-1;
        
		if (TestMode) return STATUS_OK;	// we don't emulate ramps or profiles in test mode yet

        char VNX_ramp[] = {0, 0, 0, 0, 0, 0};

        if (go)
        {
            icount = 3;                                             // V2 and later LDA devices
            VNX_ramp[0] = (char) lda[devid].Modebits[ch] & 0x1f;    // support bi-directional ramps
        }
        else
        {
            icount = 3;
            VNX_ramp[0] = 0;
        }

		if (DEBUG_OUT > 0) printf("Ramp Start: Devid: %d, Mode: %x\n",devid, VNX_ramp[0]);

        if (!SendReport(devid, VNX_SWEEP | VNX_SET, VNX_ramp, icount))
          return STATUS_ERROR;
    }
    else
        return STATUS_ERROR;
    return STATUS_OK;
}

//*****************************************************************************
//
// Function call to Start a ramp on multiple channels to the device 
// chmask has a 1 bit set for every channel to be started
// mode is composed of the sweep command byte flags SWP_DIRECTION, SWP_CONTINUOUS, SWP_ONCE, and SWP_BIDIR
// the deferred flag is not supported, but reserved for future use. Set it to false when calling
// this function for compatibility with future library versions
//
// RD 5/2024 experimental code
//*****************************************************************************
STATUS_REPORT_T fnLDA_StartRampMC(char* deviceip, int mode, int chmask, bool deferred)
{
    int bank, tmp;
    unsigned int ch, i;
    int devid = 0;

    devid = GetDeviceID(deviceip);
    if (devid >= 0)
    {
        // Check Device open or not
        if (!isDeviceSockOpen(deviceip))
            return STATUS_ERROR;

		if (TestMode) return STATUS_OK;	// we don't emulate ramps or profiles in test mode yet

        char VNX_ramp[] = {0, 0, 0, 0, 0, 0};

        if (mode != 0){
            VNX_ramp[0] = (BYTE)(mode & MODE_SWEEP);    // mode sweep for V2 includes the 0x10 bit
        }
        else {
            VNX_ramp[0] = 0;
        }

		// limit the active channels based on the number of channels in the device
		tmp = 0xFFFFFFFF >> (32 - lda[devid].NumChannels);
		chmask &= tmp;								// clip off any extraneous select bits

		for (i = 0; i < 4; i++)
		{
			tmp = chmask >> ((8 * i) & 0xff);
			if (tmp != 0)
			{
				// we have channels selected in this bank
				VNX_ramp[4] = i + 1; 
        		VNX_ramp[5] = (BYTE)tmp;	// the channel bit mask for this bank

        		if (!SendReport(devid , VNX_SWEEP | VNX_SET, (char *)VNX_ramp, 6))
				{
            		return STATUS_ERROR;
        		}
			}
		}

    }
    else
        return STATUS_ERROR;

    return STATUS_OK;
}

//*****************************************************************************
//
// Function call to SetStart a ramp on multiple channels to the device 
// chmask has a 1 bit set for every channel to be started
// mode is composed of the sweep command byte flags SWP_DIRECTION, SWP_CONTINUOUS, SWP_ONCE, and SWP_BIDIR
// the deferred flag is not supported, but reserved for future use. Set it to false when calling 
// this function for compatibility with future library versions
// Now supports a channel mask of up to 64 length
//
// NB 5/2026 experimental code
//*****************************************************************************
STATUS_REPORT_T fnLDA_StartRampMC2(char* deviceip, int mode, unsigned long long chmask, bool deferred)
{
    unsigned long long tmp64;
    unsigned int curmask;				// the channel mask for the current logical bank
    unsigned int i;
    int devid = 0;

    devid = GetDeviceID(deviceip);
    if (devid >= 0)
    {
        // Check Device open or not
        if (!isDeviceSockOpen(deviceip))
            return STATUS_ERROR;

        if (TestMode) return STATUS_OK;	// we don't emulate ramps or profiles in test mode yet

        char VNX_ramp[] = { 0, 0, 0, 0, 0, 0 };

        if (mode != 0) {
            VNX_ramp[0] = (BYTE)(mode & MODE_SWEEP);    // mode sweep for V2 includes the 0x10 bit
        }
        else {
            VNX_ramp[0] = 0;
        }

        // limit the active channels based on the number of channels in the device
        if (lda[devid].NumChannels >= 64)
        {
            tmp64 = 0xFFFFFFFFFFFFFFFFULL;
        }
        else if (lda[devid].NumChannels <= 0)
        {
            tmp64 = 0;
        }
        else
        {
            tmp64 = (1ULL << lda[devid].NumChannels) - 1;
        }
        chmask &= tmp64;

        // get rid of an easy error case, nothing to do if we don't have any channel bits set
        // but let the user know their channel mask parameter was invalid for the device
        if (chmask == 0)
        {
            return STATUS_ERROR;
        }

        for (i = 0; i < 8; i++)
        {
            // select the 8 bit wide mask for the bank
            curmask = (chmask >> (i * 8)) & 0xFF;
            if (curmask != 0)
            {
                // we have channels selected in this bank

                VNX_ramp[4] = i + 1;
                VNX_ramp[5] = (BYTE)curmask;	// the channel bit mask for this bank

                if (!SendReport(devid, VNX_SWEEP | VNX_SET, (char*)VNX_ramp, 6))
                {
                    return STATUS_ERROR;
                }
            }
        }
    }
    else
        return STATUS_ERROR;

    return STATUS_OK;
}

//*****************************************************************************
//
// Function call to Start a profile on multiple channels to the device 
// chmask has a 1 bit set for every channel to be started
// mode is PROFILE_ONCE to play the profile once, or PROFILE_REPEAT to play the profile repeatedly.
// PROFILE_OFF stops the profile
// the deferred flag is not supported, but reserved for future use. Set it to false when calling
// this function for compatibility with future library versions
//
// RD 5/2024 experimental code
//*****************************************************************************
STATUS_REPORT_T fnLDA_StartProfileMC(char* deviceip, int mode, int chmask, bool deferred)
{
    int bank, tmp;
    unsigned int ch, i;
    int devid = 0;

    devid = GetDeviceID(deviceip);
    if (devid >= 0)
    {
        // Check Device open or not
        if (!isDeviceSockOpen(deviceip))
            return STATUS_ERROR;

		if (TestMode) return STATUS_OK;	// we don't emulate ramps or profiles in test mode yet

        char VNX_command[] = {0, 0, 0, 0, 0, 0};

        if (mode != 0){
            VNX_command[0] = (BYTE) ((mode & 0x00000003) | STATUS_PROFILE_ACTIVE);  // start the profile 
        }
        else {
            VNX_command[0] = 0;
        }

		// limit the active channels based on the number of channels in the device
		tmp = 0xFFFFFFFF >> (32 - lda[devid].NumChannels);
		chmask &= tmp;								// clip off any extraneous select bits

		for (i = 0; i < 4; i++)
		{
			tmp = chmask >> ((8 * i) & 0xff);
			if (tmp != 0)
			{
				// we have channels selected in this bank

				VNX_command[4] = i + 1; 
        		VNX_command[5] = (BYTE)tmp;	// the channel bit mask for this bank

        		if (!SendReport(devid , VNX_SWEEP | VNX_SET, (char *)VNX_command, 6))
				{
            		return STATUS_ERROR;
        		}
			}
		}
    }
    else
        return STATUS_ERROR;

    return STATUS_OK;
}

//*****************************************************************************
//
// Function call to Start a profile on multiple channels to the device 
// chmask has a 1 bit set for every channel to be started
// mode is PROFILE_ONCE to play the profile once, or PROFILE_REPEAT to play the profile repeatedly.
// PROFILE_OFF stops the profile
// the deferred flag is not supported, but reserved for future use. Set it to false when calling
// this function for compatibility with future library versions
// Now supports a channel mask of up to 64 length
//
// NB 5/2026 experimental code
// NOT YET USED
// Should this replace existing fnLDA_StartProfileMC function? I'm not sure if that is used by anyone...
//*****************************************************************************
// STATUS_REPORT_T fnLDA_StartProfileMCHR(char* deviceip, int mode, unsigned long long chmask, bool deferred)
// {
//     unsigned long long tmp64;
//     unsigned int curmask;				// the channel mask for the current logical bank
//     unsigned int i;
//     int devid = 0;

//     devid = GetDeviceID(deviceip);
//     if (devid >= 0)
//     {
//         // Check Device open or not
//         if (!isDeviceSockOpen(deviceip))
//             return STATUS_ERROR;

//         if (TestMode) return STATUS_OK;	// we don't emulate ramps or profiles in test mode yet

//         char VNX_command[] = { 0, 0, 0, 0, 0, 0 };

//         if (mode != 0) {
//             VNX_command[0] = (BYTE)((mode & 0x00000003) | STATUS_PROFILE_ACTIVE);  // start the profile 
//         }
//         else {
//             VNX_command[0] = 0;
//         }

//         // limit the active channels based on the number of channels in the device
//         if (lda[devid].NumChannels >= 64)
//         {
//             tmp64 = 0xFFFFFFFFFFFFFFFFULL;
//         }
//         else if (lda[devid].NumChannels <= 0)
//         {
//             tmp64 = 0;
//         }
//         else
//         {
//             tmp64 = (1ULL << lda[devid].NumChannels) - 1;
//         }
//         chmask &= tmp64;

//         // get rid of an easy error case, nothing to do if we don't have any channel bits set
//         // but let the user know their channel mask parameter was invalid for the device
//         if (chmask == 0)
//         {
//             return STATUS_ERROR;
//         }

//         for (i = 0; i < 8; i++)
//         {
//             // select the 8 bit wide mask for the bank
//             curmask = (chmask >> (i * 8)) & 0xFF;
//             if (curmask != 0)
//             {
//                 // we have channels selected in this bank

//                 VNX_command[4] = i + 1;
//                 VNX_command[5] = (BYTE)curmask;	// the channel bit mask for this bank

//                 if (!SendReport(devid, VNX_SWEEP | VNX_SET, (char*)VNX_command, 6))
//                 {
//                     return STATUS_ERROR;
//                 }
//             }
//         }
//     }
//     else
//         return STATUS_ERROR;

//     return STATUS_OK;
// }

//*****************************************************************************
//
// Function call to save user settings to flash on device 
//  
//*****************************************************************************
STATUS_REPORT_T fnLDA_SaveSettings(char* deviceip) {
    int devid=0;
    devid = GetDeviceID(deviceip);
    if (devid >=0)
    {
        // Check Device open or not
        if (!isDeviceSockOpen(deviceip))
            return STATUS_ERROR;

        // In test mode we update our internal variables but don't talk to the hw
        if (TestMode) return STATUS_OK;

        // -- protect the LDA-602Q calibration tables on early devices
        if ((lda[devid].DevType == LDA_602Q) && (lda[devid].SerialNumber < 22160))
            return STATUS_ERROR;

        char VNX_savesettings[] = {0x42, 0x55, 0x31}; //three byte key to unlock the user protection.

        if (!SendReport(devid, VNX_SAVEPAR | VNX_SET, VNX_savesettings, 3))
            return STATUS_ERROR;
    }
    else
        return STATUS_ERROR;
  return STATUS_OK;
}
