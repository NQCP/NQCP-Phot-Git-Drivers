Read me 
-------------
Before using the example programs:

The libldasocket.so shared library should be copied to your /usr/lib directory. Normally this
copy will require elevated privileges, so your copy command will look like:

> sudo cp <location of the library> /usr/lib

-------------
To run the LDA_Eth_CLI command line example program:
> ./LDA_Eth_CLI -?

will print the help message.

> ./LDA_Eth_CLI -d 192.168.100.10 -r

will display information from the LDA device

Note that the LDA_Eth_CLI command line program interprets the command line as one complete
action, it does not interpret individual command line options in sequence like the python example
command line program.

-------------
The ldatestapp program is provided as a simple example of how to call the library, it requires that
you build it with your device's IP addresses before operation. 

-------------
The command line example programs are intended to show you how you can use the LDA socket library
from your own application software, and provide simple examples of a command line program you can
customize to perform the functions you want.
