Notes for the Vaunix LDA macOS Ethernet socket library version 0.99

The dylib libLDA_socket.dylib should be copies to the /usr/local/lib directory. 

It can be called by applications programs to control the LDA devices which have an Ethernet interface.

The library uses the same API as the macOS USB interface library with the addition of two new functions to add and remove IP addresses. Also, a
few functions operate slightly differently. Unlike the USB interface, fnLDA_InitDevice should be called before trying to read the serial number or
name of an LDA device.

For each LDA device you intend to use, call fnLDA_AddLDADevice with an IPV4 address in the form "192.168.1.21" You can add up to 64 devices. A call
to FnLDA_RemoveLDADevice with its IPV4 address will remove the device from the list of available LDA devices. Typically your application will have
a file or other persistent storage with the IP addresses assigned to the LDA devices you are using.

Once you have entered the IP addresses, call fnLDA_GetNumDevices and then fnLDA_GetDevInfo to obtain an array of device IDs for the set of LDA devices
you have. Call fnFDA_InitDevice to open the device, and then after you are done with it call fnLDA_CloseDevice. The example program shows how to use
the library for some common functions. Use the functions ending in HR, since most LDA devices with Ethernet interfaces support high resolution
attenuation control.

9/9/2024