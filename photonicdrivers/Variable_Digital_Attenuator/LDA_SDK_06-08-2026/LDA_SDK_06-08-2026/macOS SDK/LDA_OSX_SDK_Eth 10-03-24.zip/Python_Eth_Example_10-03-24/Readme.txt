Notes for the python example for ethernet control of LDA devices running on macOS
 
The dylib should be in the same folder as the python file while running.
Run via the command line with 'python3 ldaEthControl.py'
Before using the dylib, the user may need to right click on the dylib and click 'open' to allow it to run due to Mac security checks.
